/**
 * Kingdom Adventure - Main Phaser 3 Game Logic
 * 16-bit / 8-bit Pixel Platformer with Full Mobile & Desktop Controls
 */

// Global control state shared between HTML virtual buttons and Phaser
window.mobileInput = {
    left: false,
    right: false,
    jump: false,
    attack: false,
    switchWeapon: false,
    interact: false
};

// Global Game State
window.gameState = {
    selectedCharacter: 'arthur',
    coins: 0,
    chestsOpened: 0,
    skeletonsKilled: 0,
    totalChests: 4
};

// ==========================================
// 1. BOOT SCENE
// ==========================================
class BootScene extends Phaser.Scene {
    constructor() {
        super({ key: 'BootScene' });
    }

    create() {
        // Generate all procedural 16-bit / 8-bit pixel art textures
        TextureGenerator.generateAll(this);

        // Generate character avatar for HTML dialogue box
        this.generateDialogueAvatar();

        // Register Animations
        this.createAnimations();

        // Transition to Main Menu
        this.scene.start('MainMenuScene');
    }

    generateDialogueAvatar() {
        const avatarCanvas = document.getElementById('dialogue-avatar-canvas');
        if (avatarCanvas) {
            const ctx = avatarCanvas.getContext('2d');
            ctx.imageSmoothingEnabled = false;
            // Draw close-up of Arthur face
            ctx.fillStyle = '#ffdbac';
            ctx.fillRect(8, 8, 32, 32);
            // Hair
            ctx.fillStyle = '#6b4423';
            ctx.fillRect(8, 4, 32, 12);
            ctx.fillRect(6, 12, 6, 16);
            ctx.fillStyle = '#8d5b32';
            ctx.fillRect(16, 4, 16, 4);
            // Eyes
            ctx.fillStyle = '#1e293b';
            ctx.fillRect(24, 20, 6, 6);
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(26, 20, 2, 2);
            // Tunic collar
            ctx.fillStyle = '#2b6cb0';
            ctx.fillRect(6, 38, 36, 10);
            ctx.fillStyle = '#854d0e';
            ctx.fillRect(20, 36, 8, 12);
        }
    }

    createAnimations() {
        const anims = this.anims;

        // Hero animations for each armor tier
        const tiers = ['hero_tunic', 'hero_iron', 'hero_gold'];
        tiers.forEach(tier => {
            anims.create({
                key: `${tier}_idle`,
                frames: anims.generateFrameNumbers(tier, { start: 0, end: 3 }),
                frameRate: 6,
                repeat: -1
            });
            anims.create({
                key: `${tier}_run`,
                frames: anims.generateFrameNumbers(tier, { start: 4, end: 7 }),
                frameRate: 10,
                repeat: -1
            });
            anims.create({
                key: `${tier}_jump`,
                frames: [{ key: tier, frame: 8 }],
                frameRate: 1
            });
            anims.create({
                key: `${tier}_attack`,
                frames: anims.generateFrameNumbers(tier, { start: 9, end: 11 }),
                frameRate: 14,
                repeat: 0
            });
            anims.create({
                key: `${tier}_bow`,
                frames: anims.generateFrameNumbers(tier, { start: 12, end: 14 }),
                frameRate: 10,
                repeat: 0
            });
            anims.create({
                key: `${tier}_hurt`,
                frames: [{ key: tier, frame: 15 }],
                frameRate: 1
            });
        });

        // Skeleton animations
        anims.create({
            key: 'skel_walk',
            frames: anims.generateFrameNumbers('skeleton', { start: 0, end: 3 }),
            frameRate: 6,
            repeat: -1
        });
        anims.create({
            key: 'skel_attack',
            frames: anims.generateFrameNumbers('skeleton', { start: 4, end: 5 }),
            frameRate: 8,
            repeat: 0
        });
        anims.create({
            key: 'skel_hurt',
            frames: [{ key: 'skeleton', frame: 6 }],
            frameRate: 1
        });
        anims.create({
            key: 'skel_die',
            frames: [{ key: 'skeleton', frame: 7 }],
            frameRate: 1
        });

        // Princess animations
        anims.create({
            key: 'princess_idle',
            frames: [{ key: 'princess', frame: 0 }],
            frameRate: 1
        });
        anims.create({
            key: 'princess_wave',
            frames: anims.generateFrameNumbers('princess', { start: 1, end: 2 }),
            frameRate: 4,
            repeat: -1
        });
        anims.create({
            key: 'princess_shock',
            frames: [{ key: 'princess', frame: 3 }],
            frameRate: 1
        });

        // Dragon animations
        anims.create({
            key: 'dragon_fly',
            frames: anims.generateFrameNumbers('dragon', { start: 0, end: 1 }),
            frameRate: 5,
            repeat: -1
        });
        anims.create({
            key: 'dragon_roar',
            frames: [{ key: 'dragon', frame: 2 }],
            frameRate: 1
        });

        // Coins & Torches & Effects
        anims.create({
            key: 'coin_spin',
            frames: anims.generateFrameNumbers('coin', { start: 0, end: 3 }),
            frameRate: 8,
            repeat: -1
        });
        anims.create({
            key: 'torch_flicker',
            frames: anims.generateFrameNumbers('torch', { start: 0, end: 2 }),
            frameRate: 6,
            repeat: -1
        });
        anims.create({
            key: 'fireball_burn',
            frames: anims.generateFrameNumbers('projectile_fireball', { start: 0, end: 2 }),
            frameRate: 12,
            repeat: -1
        });
        anims.create({
            key: 'slash_fx',
            frames: anims.generateFrameNumbers('fx_slash', { start: 0, end: 2 }),
            frameRate: 16,
            repeat: 0
        });
    }
}

// ==========================================
// 2. MAIN MENU SCENE
// ==========================================
class MainMenuScene extends Phaser.Scene {
    constructor() {
        super({ key: 'MainMenuScene' });
    }

    create() {
        const { width, height } = this.scale;

        // Dark sky gradient & parallax mountains
        this.add.rectangle(0, 0, width, height, 0x0f172a).setOrigin(0);

        // Pixel stars/moon
        for (let i = 0; i < 40; i++) {
            const sx = Phaser.Math.Between(0, width);
            const sy = Phaser.Math.Between(0, height * 0.6);
            this.add.rectangle(sx, sy, 2, 2, 0xffffff, Phaser.Math.FloatBetween(0.3, 0.9));
        }

        // Castle silhouette back
        const bgCastle = this.add.graphics();
        bgCastle.fillStyle(0x1e293b, 1);
        bgCastle.fillRect(0, height - 120, width, 120);
        for (let b = 0; b < width; b += 40) {
            bgCastle.fillRect(b, height - 140, 24, 20);
        }

        // Floating Clouds
        this.clouds = [];
        for (let c = 0; c < 4; c++) {
            const cloud = this.add.image(c * 220 + 50, 60 + (c % 2) * 40, 'cloud')
                .setScale(1.5)
                .setAlpha(0.65);
            this.clouds.push(cloud);
        }

        // Flickering Torches on battlements
        const t1 = this.add.sprite(120, height - 130, 'torch').setScale(1.8).play('torch_flicker');
        const t2 = this.add.sprite(width - 120, height - 130, 'torch').setScale(1.8).play('torch_flicker');

        // Hero Preview (Arthur standing proudly)
        this.heroPreview = this.add.sprite(width / 2, height - 130, 'hero_tunic')
            .setScale(2.5)
            .play('hero_tunic_idle');

        // Title text with retro drop shadow
        this.add.text(width / 2 + 3, 63, 'KINGDOM ADVENTURE', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '32px',
            color: '#b45309'
        }).setOrigin(0.5);

        const titleText = this.add.text(width / 2, 60, 'KINGDOM ADVENTURE', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '32px',
            color: '#facc15'
        }).setOrigin(0.5);

        this.tweens.add({
            targets: titleText,
            scaleY: 1.05,
            duration: 900,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });

        this.add.text(width / 2, 105, '— 16-BIT RETRO PLATFORMER —', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '11px',
            color: '#94a3b8'
        }).setOrigin(0.5);

        // Menu Buttons
        this.createMenuButton(width / 2, 220, '▶  ИГРАТЬ (УРОВЕНЬ 1)', () => {
            window.soundEngine.playJump();
            this.scene.start('GameScene');
        });

        this.createMenuButton(width / 2, 275, '👤  ВЫБОР ПЕРСОНАЖА', () => {
            window.soundEngine.playCoin();
            this.scene.start('CharSelectScene');
        });

        this.createMenuButton(width / 2, 330, '⚙  УПРАВЛЕНИЕ И ПРАВИЛА', () => {
            window.soundEngine.playChestOpen();
            this.showHelpModal();
        });

        // Version & Credits
        this.add.text(width / 2, height - 20, 'HTML5 Phaser 3 Edition • ПК + Смартфон', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '8px',
            color: '#64748b'
        }).setOrigin(0.5);
    }

    update() {
        if (this.clouds) {
            this.clouds.forEach(c => {
                c.x += 0.3;
                if (c.x > this.scale.width + 80) c.x = -80;
            });
        }
    }

    createMenuButton(x, y, text, callback) {
        const btnBg = this.add.rectangle(x, y, 380, 42, 0x1e293b)
            .setStrokeStyle(3, 0x3b82f6)
            .setInteractive({ useHandCursor: true });

        const btnText = this.add.text(x, y, text, {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '11px',
            color: '#f8fafc'
        }).setOrigin(0.5);

        btnBg.on('pointerover', () => {
            btnBg.setFillStyle(0x3b82f6);
            btnBg.setStrokeStyle(3, 0xfacc15);
            btnText.setColor('#ffffff');
            btnBg.setScale(1.03);
            btnText.setScale(1.03);
        });

        btnBg.on('pointerout', () => {
            btnBg.setFillStyle(0x1e293b);
            btnBg.setStrokeStyle(3, 0x3b82f6);
            btnText.setColor('#f8fafc');
            btnBg.setScale(1);
            btnText.setScale(1);
        });

        btnBg.on('pointerdown', callback);
    }

    showHelpModal() {
        const { width, height } = this.scale;
        const overlay = this.add.rectangle(0, 0, width, height, 0x000000, 0.85).setOrigin(0).setInteractive();

        const box = this.add.rectangle(width / 2, height / 2, 580, 320, 0x111827).setStrokeStyle(4, 0xf59e0b);

        const helpTitle = this.add.text(width / 2, height / 2 - 130, 'УПРАВЛЕНИЕ И СЮЖЕТ', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '14px',
            color: '#fde047'
        }).setOrigin(0.5);

        const helpContent = [
            '⚔ МЕЧ: ЛКМ или кнопка [⚔ УДАР]',
            '🏹 ЛУК / 🔮 МАГИЯ: Прицеливание мышью или тапом',
            '🔄 СМЕНА ОРУЖИЯ: Клавиша Q, 1-2-3 или [🔄 ОРУЖИЕ]',
            '🏃 ДВИЖЕНИЕ: A / D или [◀ / ▶]',
            '▲ ПРЫЖОК: Space / W или [▲ ПРЫЖОК]',
            '🗝 СУНДУКИ: Клавиша E или [✋ ЛУТ]',
            '----------------------------------------',
            'Цель: Доберись до Башни Принцессы в конце уровня!',
            'Остерегайся скелетов и собирай броню из сундуков.'
        ].join('\n\n');

        const helpText = this.add.text(width / 2, height / 2 - 10, helpContent, {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '9px',
            color: '#cbd5e1',
            align: 'center',
            lineSpacing: 4
        }).setOrigin(0.5);

        const closeBtn = this.add.rectangle(width / 2, height / 2 + 125, 200, 36, 0xd97706)
            .setStrokeStyle(2, 0xfef08a)
            .setInteractive({ useHandCursor: true });

        const closeText = this.add.text(width / 2, height / 2 + 125, 'ПОНЯТНО', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '11px',
            color: '#451a03'
        }).setOrigin(0.5);

        const destroyHelp = () => {
            overlay.destroy();
            box.destroy();
            helpTitle.destroy();
            helpText.destroy();
            closeBtn.destroy();
            closeText.destroy();
        };

        closeBtn.on('pointerdown', destroyHelp);
        overlay.on('pointerdown', destroyHelp);
    }
}

// ==========================================
// 3. CHARACTER SELECT SCENE
// ==========================================
class CharSelectScene extends Phaser.Scene {
    constructor() {
        super({ key: 'CharSelectScene' });
    }

    create() {
        const { width, height } = this.scale;

        this.add.rectangle(0, 0, width, height, 0x0f172a).setOrigin(0);

        this.add.text(width / 2, 40, 'ВЫБОР ПЕРСОНАЖА', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '20px',
            color: '#facc15'
        }).setOrigin(0.5);

        // Three character showcase cards
        const cards = [
            {
                id: 'arthur',
                name: 'АРТУР (ВОИН)',
                tag: 'ДОСТУПЕН',
                desc: 'Храбрый юноша в стартовой тунике.\nСбалансированный герой королевства.',
                stats: 'HP: 100 | Скорость: ★★★ | Урон: ★★★',
                sprite: 'hero_tunic',
                unlocked: true
            },
            {
                id: 'lyra',
                name: 'ЛИРА (ЛУЧНИЦА)',
                tag: 'СКОРО',
                desc: 'Эльфийская следопыт из лесов.\nПовышенный урон из лука.',
                stats: 'HP: 85  | Скорость: ★★★★| Урон: ★★★',
                sprite: 'hero_iron',
                unlocked: false
            },
            {
                id: 'aldor',
                name: 'АЛДОР (МАГ)',
                tag: 'СКОРО',
                desc: 'Верховный чародей королевской башни.\nВладеет разрушительным огнем.',
                stats: 'HP: 75  | Скорость: ★★  | Урон: ★★★★★',
                sprite: 'hero_gold',
                unlocked: false
            }
        ];

        const cardWidth = 230;
        const startX = (width - (cardWidth * 3 + 40)) / 2 + cardWidth / 2;

        cards.forEach((c, idx) => {
            const cx = startX + idx * (cardWidth + 20);
            const cy = 190;

            const cardBox = this.add.rectangle(cx, cy, cardWidth, 240, c.unlocked ? 0x1e293b : 0x111827)
                .setStrokeStyle(3, c.unlocked ? 0x22c55e : 0x475569);

            this.add.text(cx, cy - 95, c.name, {
                fontFamily: '"Press Start 2P", monospace',
                fontSize: '10px',
                color: c.unlocked ? '#fde047' : '#94a3b8'
            }).setOrigin(0.5);

            // Sprite preview
            const spr = this.add.sprite(cx, cy - 40, c.sprite)
                .setScale(2.2);
            if (c.unlocked) spr.play(`${c.sprite}_idle`);

            // Tag badge
            const badge = this.add.rectangle(cx, cy + 15, 160, 22, c.unlocked ? 0x15803d : 0x334155)
                .setStrokeStyle(1, c.unlocked ? 0x86efac : 0x64748b);
            this.add.text(cx, cy + 15, c.tag, {
                fontFamily: '"Press Start 2P", monospace',
                fontSize: '8px',
                color: c.unlocked ? '#f0fdf4' : '#94a3b8'
            }).setOrigin(0.5);

            this.add.text(cx, cy + 50, c.desc, {
                fontFamily: '"Press Start 2P", monospace',
                fontSize: '7px',
                color: '#cbd5e1',
                align: 'center',
                lineSpacing: 3
            }).setOrigin(0.5);

            this.add.text(cx, cy + 95, c.stats, {
                fontFamily: '"Press Start 2P", monospace',
                fontSize: '6px',
                color: '#38bdf8'
            }).setOrigin(0.5);

            if (c.unlocked) {
                cardBox.setInteractive({ useHandCursor: true });
                cardBox.on('pointerdown', () => {
                    window.gameState.selectedCharacter = c.id;
                    window.soundEngine.playCoin();
                });
            }
        });

        // Bottom Controls
        const backBtn = this.add.rectangle(width / 2 - 130, height - 50, 220, 40, 0x334155)
            .setStrokeStyle(2, 0x64748b)
            .setInteractive({ useHandCursor: true });
        this.add.text(width / 2 - 130, height - 50, '◀ В ГЛАВНОЕ МЕНЮ', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '9px',
            color: '#ffffff'
        }).setOrigin(0.5);

        backBtn.on('pointerdown', () => {
            window.soundEngine.playJump();
            this.scene.start('MainMenuScene');
        });

        const startBtn = this.add.rectangle(width / 2 + 130, height - 50, 220, 40, 0x16a34a)
            .setStrokeStyle(3, 0x86efac)
            .setInteractive({ useHandCursor: true });
        this.add.text(width / 2 + 130, height - 50, 'В БОЙ! ▶', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '11px',
            color: '#ffffff'
        }).setOrigin(0.5);

        startBtn.on('pointerdown', () => {
            window.soundEngine.playJump();
            this.scene.start('GameScene');
        });
    }
}

// ==========================================
// 4. MAIN GAMEPLAY SCENE (LEVEL 1)
// ==========================================
class GameScene extends Phaser.Scene {
    constructor() {
        super({ key: 'GameScene' });
    }

    create() {
        // Reset Level Session Stats
        this.levelWidth = 3600;
        this.levelHeight = 450;
        this.physics.world.setBounds(0, 0, this.levelWidth, this.levelHeight + 100);

        this.inCutscene = false;
        this.isGameOver = false;
        this.score = 0;
        this.coinsCollected = 0;
        this.chestsOpened = 0;
        this.skeletonsDefeated = 0;

        // Player Stats & State
        this.playerMaxHp = 100;
        this.playerHp = 100;
        this.currentArmor = 'hero_tunic';
        this.armorName = 'Стартовая туника';
        this.isInvulnerable = false;
        this.invulnerableTimer = 0;

        // Weapons: 0: Sword, 1: Bow, 2: Fire Staff
        this.weaponsUnlocked = {
            sword: true,
            bow: false,
            staff: false
        };
        this.activeWeapon = 'sword'; // 'sword', 'bow', 'staff'
        this.lastAttackTime = 0;
        this.facingDirection = 1; // 1 = right, -1 = left

        // Mario-style Coyote time & Jump buffer
        this.coyoteCounter = 0;
        this.jumpBuffer = 0;

        // Build Environment, Platforms, Parallax Background
        this.createEnvironment();

        // Groups
        this.platforms = this.physics.add.staticGroup();
        this.woodPlatforms = this.physics.add.staticGroup();
        this.spikes = this.physics.add.staticGroup();
        this.chests = this.physics.add.staticGroup();
        this.skeletons = this.physics.add.group();
        this.coins = this.physics.add.group();
        this.arrows = this.physics.add.group();
        this.fireballs = this.physics.add.group();

        // Build Level Platforms & Place Assets
        this.buildLevelLayout();

        // Spawn Player
        this.spawnPlayer(100, 300);

        // Spawn Princess & Tower
        this.spawnTowerAndPrincess();

        // Spawn Dragon (initially hidden off-screen)
        this.spawnDragon();

        // Setup Colliders
        this.setupCollisions();

        // Camera Setup
        this.cameras.main.setBounds(0, 0, this.levelWidth, this.levelHeight);
        this.cameras.main.startFollow(this.player, true, 0.1, 0.1, 0, 40);

        // Input Setup (Keyboard & Mouse)
        this.setupInputs();

        // HUD Overlay
        this.createHUD();

        // Crosshair / Aim trajectory line
        this.aimTrajectory = this.add.graphics().setDepth(50);
        this.crosshair = this.add.image(0, 0, 'crosshair').setVisible(false).setDepth(51);

        // Wire HTML Virtual Buttons
        this.bindVirtualTouchControls();

        // Notification floating text group
        this.notifGroup = this.add.group();
    }

    // ----------------------------------------------------
    // LEVEL ENVIRONMENT & PARALLAX
    // ----------------------------------------------------
    createEnvironment() {
        // Deep Sky Gradient
        this.add.rectangle(0, 0, this.levelWidth, this.levelHeight, 0x0f172a)
            .setOrigin(0)
            .setScrollFactor(0);

        // Distant Parallax Mountain Peaks
        const mountainGfx = this.add.graphics().setScrollFactor(0.15);
        mountainGfx.fillStyle(0x1e293b, 1);
        for (let m = 0; m < this.levelWidth + 400; m += 260) {
            mountainGfx.beginPath();
            mountainGfx.moveTo(m - 140, 450);
            mountainGfx.lineTo(m, 180 + (m % 3) * 30);
            mountainGfx.lineTo(m + 140, 450);
            mountainGfx.closePath();
            mountainGfx.fill();
        }

        // Castle Wall Silhouettes & Battlements
        const castleGfx = this.add.graphics().setScrollFactor(0.3);
        castleGfx.fillStyle(0x273549, 1);
        castleGfx.fillRect(0, 310, this.levelWidth, 140);
        for (let c = 0; c < this.levelWidth; c += 50) {
            castleGfx.fillRect(c, 290, 28, 20);
        }

        // Parallax Clouds
        this.bgClouds = [];
        for (let i = 0; i < 18; i++) {
            const cl = this.add.image(i * 240 + Phaser.Math.Between(0, 80), Phaser.Math.Between(30, 110), 'cloud')
                .setScrollFactor(0.25)
                .setScale(Phaser.Math.FloatBetween(1.2, 2.0))
                .setAlpha(0.6);
            this.bgClouds.push(cl);
        }
    }

    buildLevelLayout() {
        const TILE = 32;

        // Helper to place ground blocks
        const placeGround = (startX, count, topY) => {
            for (let i = 0; i < count; i++) {
                const x = startX + i * TILE + TILE / 2;
                // Grass Top
                const topTile = this.platforms.create(x, topY, 'tile_grass');
                topTile.refreshBody();
                // Dirt below
                for (let d = topY + TILE; d <= this.levelHeight + TILE; d += TILE) {
                    this.platforms.create(x, d, 'tile_dirt').refreshBody();
                }
            }
        };

        // Helper for stone structures
        const placeStonePlatform = (startX, count, y) => {
            for (let i = 0; i < count; i++) {
                const x = startX + i * TILE + TILE / 2;
                this.platforms.create(x, y, 'tile_stone').refreshBody();
            }
        };

        // Helper for wood bridges
        const placeWoodBridge = (startX, count, y) => {
            for (let i = 0; i < count; i++) {
                const x = startX + i * TILE + TILE / 2;
                const wood = this.woodPlatforms.create(x, y, 'tile_wood');
                wood.refreshBody();
            }
        };

        // Helper for deadly spikes in pits
        const placeSpikes = (startX, count, y) => {
            for (let i = 0; i < count; i++) {
                const x = startX + i * TILE + TILE / 2;
                const spk = this.spikes.create(x, y, 'tile_spikes');
                spk.refreshBody();
            }
        };

        // --- LEVEL TERRAIN GEOGRAPHY ---

        // Sector 1: Starter Meadow (x: 0 - 520)
        placeGround(0, 16, 380);
        this.add.sprite(200, 340, 'torch').play('torch_flicker');

        // Sector 1 Pit & Floating Bridge (x: 520 - 740)
        placeSpikes(530, 6, 430);
        placeWoodBridge(560, 4, 300);

        // Island 1 with CHEST 1: Hunter's Bow (x: 740 - 1100)
        placeGround(740, 11, 380);
        this.placeChest(860, 350, 'bow', 'Лук охотника', 'Оружие дальнего боя (Клавиша Q)');
        this.spawnSkeleton(960, 340, 780, 1060);

        // Sector 2: Stone Ruins & Stepped Cliffs (x: 1100 - 1650)
        placeWoodBridge(1120, 3, 310);
        placeStonePlatform(1240, 8, 330);
        placeStonePlatform(1340, 5, 250);
        // Chest 2: Iron Knight Armor atop ruin
        this.placeChest(1400, 220, 'iron_armor', 'Железные латы', '+40 HP! Новый облик рыцаря!');
        this.spawnSkeleton(1270, 290, 1240, 1480);
        this.spawnSkeleton(1440, 290, 1300, 1500);

        // Deep chasm with spikes (x: 1520 - 1750)
        placeSpikes(1540, 6, 430);
        placeWoodBridge(1580, 3, 260);

        // Sector 3: Valley of the Crypts (x: 1750 - 2350)
        placeGround(1750, 18, 380);
        this.add.sprite(1820, 340, 'torch').play('torch_flicker');
        this.add.sprite(2200, 340, 'torch').play('torch_flicker');
        this.spawnSkeleton(1900, 340, 1780, 2050);
        this.spawnSkeleton(2100, 340, 1950, 2300);

        // Chest 3: Fire Staff
        placeStonePlatform(2180, 4, 280);
        this.placeChest(2240, 250, 'staff', 'Огненный посох', 'Стреляет мощными огненными шарами!');

        // Sector 4: The Elevated Bastion (x: 2350 - 2950)
        placeWoodBridge(2380, 3, 320);
        placeStonePlatform(2500, 12, 340);
        placeStonePlatform(2620, 6, 240);
        this.spawnSkeleton(2550, 300, 2500, 2850);
        this.spawnSkeleton(2720, 200, 2630, 2800);

        // Chest 4: Golden Paladin Armor
        this.placeChest(2740, 210, 'gold_armor', 'Золотой доспех', '+60 HP! Легендарный плащ паладина!');

        // Sector 5: Grand Castle Courtyard approaching Tower (x: 2950 - 3600)
        placeGround(2950, 22, 380);
        this.spawnSkeleton(3040, 340, 2960, 3120);

        // Courtyard Royal Banners & Torches
        this.add.image(3120, 320, 'banner');
        this.add.sprite(3160, 340, 'torch').play('torch_flicker');
        this.add.sprite(3350, 340, 'torch').play('torch_flicker');

        // Coins scattered across level
        const coinLocations = [
            240, 330, 580, 260, 620, 260, 1020, 340, 1140, 270,
            1380, 210, 1600, 220, 1850, 340, 2020, 340, 2220, 240,
            2650, 200, 3010, 340, 3080, 340
        ];
        for (let i = 0; i < coinLocations.length; i += 2) {
            const coin = this.coins.create(coinLocations[i], coinLocations[i + 1], 'coin');
            coin.play('coin_spin');
            coin.body.setAllowGravity(false);
        }
    }

    // ----------------------------------------------------
    // CHESTS SYSTEM
    // ----------------------------------------------------
    placeChest(x, y, rewardType, name, desc) {
        const chest = this.chests.create(x, y, 'chest', 0);
        chest.setDepth(10);
        chest.rewardType = rewardType;
        chest.rewardName = name;
        chest.rewardDesc = desc;
        chest.opened = false;
        chest.refreshBody();
    }

    openChest(chest) {
        if (chest.opened) return;
        chest.opened = true;
        chest.setFrame(1); // open chest frame
        this.chestsOpened++;
        window.gameState.chestsOpened = this.chestsOpened;

        window.soundEngine.playChestOpen();

        // Particles
        for (let p = 0; p < 12; p++) {
            const spark = this.add.image(chest.x + Phaser.Math.Between(-10, 10), chest.y - 10, 'particle_spark');
            this.tweens.add({
                targets: spark,
                x: spark.x + Phaser.Math.Between(-30, 30),
                y: spark.y - Phaser.Math.Between(20, 60),
                alpha: 0,
                scale: 1.5,
                duration: 700,
                onComplete: () => spark.destroy()
            });
        }

        // Apply Reward
        if (chest.rewardType === 'bow') {
            this.weaponsUnlocked.bow = true;
            this.activeWeapon = 'bow';
            this.showFloatingText(chest.x, chest.y - 40, `ПОЛУЧЕН: ${chest.rewardName}!`, '#38bdf8');
            this.showFloatingText(chest.x, chest.y - 20, chest.rewardDesc, '#fef08a');
        } else if (chest.rewardType === 'staff') {
            this.weaponsUnlocked.staff = true;
            this.activeWeapon = 'staff';
            this.showFloatingText(chest.x, chest.y - 40, `ПОЛУЧЕН: ${chest.rewardName}!`, '#a855f7');
            this.showFloatingText(chest.x, chest.y - 20, chest.rewardDesc, '#fef08a');
        } else if (chest.rewardType === 'iron_armor') {
            this.currentArmor = 'hero_iron';
            this.armorName = 'Железные латы';
            this.playerMaxHp = 140;
            this.playerHp = 140; // fully heal
            this.player.setTexture('hero_iron');
            this.showFloatingText(chest.x, chest.y - 40, `ОБНОВЛЕН ДОСПЕХ: ${chest.rewardName}!`, '#22c55e');
            this.showFloatingText(chest.x, chest.y - 20, chest.rewardDesc, '#fef08a');
        } else if (chest.rewardType === 'gold_armor') {
            this.currentArmor = 'hero_gold';
            this.armorName = 'Золотой доспех паладина';
            this.playerMaxHp = 200;
            this.playerHp = 200; // fully heal
            this.player.setTexture('hero_gold');
            this.showFloatingText(chest.x, chest.y - 40, `ЛЕГЕНДАРНЫЙ ДОСПЕХ: ${chest.rewardName}!`, '#eab308');
            this.showFloatingText(chest.x, chest.y - 20, chest.rewardDesc, '#fef08a');
        }

        this.updateHUD();
    }

    // ----------------------------------------------------
    // PLAYER SETUP
    // ----------------------------------------------------
    spawnPlayer(x, y) {
        this.player = this.physics.add.sprite(x, y, this.currentArmor);
        this.player.setCollideWorldBounds(true);
        this.player.setSize(18, 28);
        this.player.setOffset(7, 4);
        this.player.setDepth(20);
        this.player.play(`${this.currentArmor}_idle`);

        this.player.on('animationcomplete', (anim) => {
            if (anim.key.includes('attack') || anim.key.includes('bow') || anim.key.includes('hurt')) {
                const onGround = this.player.body.blocked.down || this.player.body.touching.down;
                if (onGround) {
                    if (Math.abs(this.player.body.velocity.x) > 10) {
                        this.player.play(`${this.currentArmor}_run`, true);
                    } else {
                        this.player.play(`${this.currentArmor}_idle`, true);
                    }
                } else {
                    this.player.play(`${this.currentArmor}_jump`, true);
                }
            }
        });

        this.lastSafeX = x;
        this.lastSafeY = y;
    }

    // ----------------------------------------------------
    // SKELETON ENEMIES SETUP & AI
    // ----------------------------------------------------
    spawnSkeleton(x, y, leftBound, rightBound) {
        const skel = this.skeletons.create(x, y, 'skeleton');
        skel.setSize(20, 28);
        skel.setOffset(6, 4);
        skel.setCollideWorldBounds(true);
        skel.setDepth(19);

        skel.hp = 60;
        skel.maxHp = 60;
        skel.speed = 65;
        skel.leftBound = leftBound;
        skel.rightBound = rightBound;
        skel.patrolDir = 1;
        skel.isAttacking = false;
        skel.isDead = false;
        skel.play('skel_walk');

        // Health bar graphics for skeleton
        skel.hpBar = this.add.graphics().setDepth(22);
    }

    updateSkeletonAI() {
        this.skeletons.children.iterate((skel) => {
            if (!skel || !skel.active || skel.isDead) return;

            // Update mini HP bar above skeleton
            skel.hpBar.clear();
            if (skel.hp < skel.maxHp) {
                skel.hpBar.fillStyle(0x000000, 0.7);
                skel.hpBar.fillRect(skel.x - 14, skel.y - 24, 28, 4);
                const hpPct = Math.max(0, skel.hp / skel.maxHp);
                skel.hpBar.fillStyle(0xef4444, 1);
                skel.hpBar.fillRect(skel.x - 14, skel.y - 24, 28 * hpPct, 4);
            }

            if (skel.isAttacking) return;

            const distToPlayer = Phaser.Math.Distance.Between(skel.x, skel.y, this.player.x, this.player.y);

            // Aggro Range: 180px
            if (distToPlayer < 180 && Math.abs(skel.y - this.player.y) < 60) {
                // Chase player
                const dir = this.player.x < skel.x ? -1 : 1;
                skel.setVelocityX(dir * (skel.speed * 1.5));
                skel.setFlipX(dir < 0);

                // Melee strike range: 32px
                if (distToPlayer < 36 && !skel.isAttacking) {
                    this.skeletonAttack(skel);
                }
            } else {
                // Patrol between bounds
                if (skel.x <= skel.leftBound) skel.patrolDir = 1;
                if (skel.x >= skel.rightBound) skel.patrolDir = -1;

                skel.setVelocityX(skel.patrolDir * skel.speed);
                skel.setFlipX(skel.patrolDir < 0);
            }
        });
    }

    skeletonAttack(skel) {
        skel.isAttacking = true;
        skel.setVelocityX(0);
        skel.play('skel_attack');

        this.time.delayedCall(250, () => {
            if (skel.active && !skel.isDead) {
                const dist = Phaser.Math.Distance.Between(skel.x, skel.y, this.player.x, this.player.y);
                if (dist < 40) {
                    this.damagePlayer(15, skel.x);
                }
            }
        });

        this.time.delayedCall(600, () => {
            if (skel.active && !skel.isDead) {
                skel.isAttacking = false;
                skel.play('skel_walk');
            }
        });
    }

    damageSkeleton(skel, damage, hitX) {
        if (skel.isDead) return;

        skel.hp -= damage;
        window.soundEngine.playHit();

        // Flash and knockback
        skel.play('skel_hurt');
        const knockDir = (skel.x < hitX) ? -1 : 1;
        skel.setVelocityX(knockDir * 140);
        skel.setVelocityY(-100);

        this.showFloatingText(skel.x, skel.y - 15, `-${damage}`, '#f87171');

        if (skel.hp <= 0) {
            this.killSkeleton(skel);
        } else {
            this.time.delayedCall(200, () => {
                if (skel.active && !skel.isDead) {
                    skel.play('skel_walk');
                }
            });
        }
    }

    killSkeleton(skel) {
        skel.isDead = true;
        skel.setVelocity(0, 0);
        skel.body.setEnable(false);
        skel.play('skel_die');
        skel.hpBar.clear();
        window.soundEngine.playEnemyDeath();

        this.skeletonsDefeated++;
        window.gameState.skeletonsKilled = this.skeletonsDefeated;

        // Drop 2-3 Coins with physics bounce
        const coinCount = Phaser.Math.Between(2, 3);
        for (let i = 0; i < coinCount; i++) {
            const c = this.coins.create(skel.x + Phaser.Math.Between(-10, 10), skel.y - 10, 'coin');
            c.play('coin_spin');
            c.setVelocity(Phaser.Math.Between(-80, 80), Phaser.Math.Between(-180, -90));
            c.setBounce(0.5);
            c.setCollideWorldBounds(true);
        }

        this.time.delayedCall(1500, () => {
            if (skel) skel.destroy();
        });

        this.updateHUD();
    }

    // ----------------------------------------------------
    // TOWER & PRINCESS CUTSCENE SETUP
    // ----------------------------------------------------
    spawnTowerAndPrincess() {
        const towerX = 3300;
        const groundY = 380;

        // High stone tower background tiles (from y: 60 to 380)
        for (let ty = groundY - 32; ty >= 80; ty -= 32) {
            for (let tx = towerX - 64; tx <= towerX + 64; tx += 32) {
                this.add.image(tx, ty, 'tile_tower').setDepth(5);
            }
        }

        // Tower Parapets / Battlements
        for (let tx = towerX - 64; tx <= towerX + 64; tx += 32) {
            this.add.image(tx, 64, 'tile_battlement').setDepth(6);
        }

        // Tower Entrance Door at bottom
        this.towerDoor = this.add.image(towerX, groundY - 24, 'tower_door').setDepth(6);

        // Princess Balcony platform at top
        this.platforms.create(towerX, 100, 'tile_stone').refreshBody().setDepth(6);
        this.add.image(towerX, 90, 'tile_battlement').setDepth(7);

        // Princess sprite
        this.princess = this.add.sprite(towerX, 74, 'princess')
            .setDepth(8)
            .play('princess_wave');

        // Cutscene trigger zone around tower door
        this.cutsceneTriggerX = 3180;
    }

    spawnDragon() {
        // Dragon initially stays off-screen in upper sky
        this.dragon = this.physics.add.sprite(3800, -100, 'dragon')
            .setDepth(30)
            .play('dragon_fly');
        this.dragon.body.setAllowGravity(false);
        this.dragon.setVisible(false);
    }

    // ----------------------------------------------------
    // CLIMAX CUTSCENE EXECUTION
    // ----------------------------------------------------
    startTowerCutscene() {
        if (this.inCutscene) return;
        this.inCutscene = true;

        // Stop player
        this.player.setVelocityX(0);
        this.player.play(`${this.currentArmor}_idle`);

        // Pan camera smoothly to center tower
        this.cameras.main.stopFollow();
        this.cameras.main.pan(3300, 200, 1500, 'Power2');

        // Step 1: Arthur speaks
        this.time.delayedCall(1600, () => {
            this.showDialogue('Артур', '«Впусти меня в башню! Я прибыл, чтобы защитить тебя!»');

            // Step 2: Princess cries out
            this.time.delayedCall(2800, () => {
                this.princess.play('princess_shock');
                this.showDialogue('Принцесса', '«Артур! Берегись небес! Оно приближается!..»');

                // Step 3: Dragon swoops in
                this.time.delayedCall(2200, () => {
                    this.hideDialogue();
                    window.soundEngine.playDragonRoar();
                    this.cameras.main.shake(1200, 0.015);

                    this.dragon.setVisible(true);
                    this.dragon.setPosition(3500, -80);
                    this.dragon.setFlipX(true); // faces left towards tower

                    // Swoop down to balcony
                    this.tweens.add({
                        targets: this.dragon,
                        x: 3300,
                        y: 70,
                        duration: 1600,
                        ease: 'Quad.easeInOut',
                        onComplete: () => {
                            // Dragon snatches Princess
                            this.dragon.play('dragon_roar');
                            this.showDialogue('Принцесса', '«А-А-А-А! ПОМОГИ МНЕ, АРТУР!»');

                            // Attach princess to dragon claws
                            this.princess.setVisible(false);

                            // Dragon roars and flies away towards Level 10
                            this.time.delayedCall(1200, () => {
                                window.soundEngine.playDragonRoar();
                                this.hideDialogue();
                                this.dragon.play('dragon_fly');
                                this.dragon.setFlipX(false); // turn towards right

                                this.tweens.add({
                                    targets: this.dragon,
                                    x: 3900,
                                    y: -150,
                                    duration: 2500,
                                    ease: 'Quad.easeIn',
                                    onComplete: () => {
                                        // Level Complete Celebration
                                        window.soundEngine.playVictoryJingle();
                                        this.showLevelCompleteModal();
                                    }
                                });
                            });
                        }
                    });
                });
            });
        });
    }

    showDialogue(speaker, text) {
        const modal = document.getElementById('dialogue-modal');
        const speakerEl = document.getElementById('dialogue-speaker');
        const textEl = document.getElementById('dialogue-text');
        if (modal && speakerEl && textEl) {
            speakerEl.textContent = speaker;
            textEl.textContent = text;
            modal.style.display = 'block';
        }
    }

    hideDialogue() {
        const modal = document.getElementById('dialogue-modal');
        if (modal) modal.style.display = 'none';
    }

    showLevelCompleteModal() {
        const modal = document.getElementById('level-complete-modal');
        const statEnemies = document.getElementById('stat-enemies');
        const statCoins = document.getElementById('stat-coins');
        const statChests = document.getElementById('stat-chests');

        if (statEnemies) statEnemies.textContent = this.skeletonsDefeated;
        if (statCoins) statCoins.textContent = this.coinsCollected;
        if (statChests) statChests.textContent = this.chestsOpened;

        if (modal) modal.style.display = 'block';

        // Replay button
        const btnReplay = document.getElementById('btn-replay');
        if (btnReplay) {
            btnReplay.onclick = () => {
                modal.style.display = 'none';
                this.scene.restart();
            };
        }

        // Next Level button
        const btnNext = document.getElementById('btn-next-level');
        if (btnNext) {
            btnNext.onclick = () => {
                modal.style.display = 'none';
                this.scene.restart();
            };
        }
    }

    // ----------------------------------------------------
    // COMBAT & ATTACK EXECUTION
    // ----------------------------------------------------
    performAttack() {
        if (this.inCutscene || this.isGameOver) return;

        const now = this.time.now;
        if (now - this.lastAttackTime < 320) return; // cooldown
        this.lastAttackTime = now;

        if (this.activeWeapon === 'sword') {
            this.swingSword();
        } else if (this.activeWeapon === 'bow') {
            this.shootBow();
        } else if (this.activeWeapon === 'staff') {
            this.castFireball();
        }
    }

    swingSword() {
        this.player.play(`${this.currentArmor}_attack`);
        window.soundEngine.playSlash();

        // Slash arc effect
        const slashX = this.player.x + (this.facingDirection * 22);
        const slashY = this.player.y;
        const slash = this.add.sprite(slashX, slashY, 'fx_slash')
            .setDepth(25)
            .setFlipX(this.facingDirection < 0)
            .play('slash_fx');

        slash.on('animationcomplete', () => slash.destroy());

        // Hit check on skeletons in arc
        const swordDamage = (this.currentArmor === 'hero_gold') ? 60 : (this.currentArmor === 'hero_iron' ? 45 : 30);

        this.skeletons.children.iterate((skel) => {
            if (!skel || !skel.active || skel.isDead) return;
            const dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, skel.x, skel.y);
            const inFront = (this.facingDirection > 0 && skel.x >= this.player.x - 10) ||
                            (this.facingDirection < 0 && skel.x <= this.player.x + 10);
            if (dist < 46 && inFront) {
                this.damageSkeleton(skel, swordDamage, this.player.x);
            }
        });
    }

    shootBow() {
        this.player.play(`${this.currentArmor}_bow`);
        window.soundEngine.playBowShoot();

        const spawnX = this.player.x + this.facingDirection * 14;
        const spawnY = this.player.y - 2;

        const arrow = this.arrows.create(spawnX, spawnY, 'projectile_arrow');
        arrow.setDepth(24);

        // Calculate aim angle from crosshair/pointer
        const pointer = this.input.activePointer;
        const worldPointer = this.cameras.main.getWorldPoint(pointer.x, pointer.y);
        const angle = Phaser.Math.Angle.Between(spawnX, spawnY, worldPointer.x, worldPointer.y);

        const speed = 480;
        arrow.setVelocity(Math.cos(angle) * speed, Math.sin(angle) * speed);
        arrow.setRotation(angle);
        arrow.body.setAllowGravity(true);
        arrow.body.setGravityY(160); // ballistic arc
    }

    castFireball() {
        this.player.play(`${this.currentArmor}_attack`);
        window.soundEngine.playFireball();

        const spawnX = this.player.x + this.facingDirection * 16;
        const spawnY = this.player.y - 2;

        const fb = this.fireballs.create(spawnX, spawnY, 'projectile_fireball');
        fb.setDepth(24);
        fb.play('fireball_burn');

        const pointer = this.input.activePointer;
        const worldPointer = this.cameras.main.getWorldPoint(pointer.x, pointer.y);
        const angle = Phaser.Math.Angle.Between(spawnX, spawnY, worldPointer.x, worldPointer.y);

        const speed = 400;
        fb.setVelocity(Math.cos(angle) * speed, Math.sin(angle) * speed);
        fb.body.setAllowGravity(false); // straight magical bolt
    }

    switchWeaponNext() {
        const available = ['sword'];
        if (this.weaponsUnlocked.bow) available.push('bow');
        if (this.weaponsUnlocked.staff) available.push('staff');

        const curIdx = available.indexOf(this.activeWeapon);
        const nextIdx = (curIdx + 1) % available.length;
        this.activeWeapon = available[nextIdx];

        window.soundEngine.playJump();
        this.updateHUD();

        const names = { sword: 'МЕЧ', bow: 'ЛУК ОХОТНИКА', staff: 'ОГНЕННЫЙ ПОСОХ' };
        this.showFloatingText(this.player.x, this.player.y - 30, `Оружие: ${names[this.activeWeapon]}`, '#38bdf8');
    }

    // ----------------------------------------------------
    // PLAYER DAMAGE & HEALTH
    // ----------------------------------------------------
    damagePlayer(amount, hitSourceX) {
        if (this.isInvulnerable || this.inCutscene || this.isGameOver) return;

        this.playerHp = Math.max(0, this.playerHp - amount);
        this.isInvulnerable = true;
        this.invulnerableTimer = 60; // 1 second of blinking

        window.soundEngine.playHit();
        this.cameras.main.shake(150, 0.01);

        this.player.play(`${this.currentArmor}_hurt`);

        // Knockback
        const dir = (this.player.x < hitSourceX) ? -1 : 1;
        this.player.setVelocityX(dir * 180);
        this.player.setVelocityY(-140);

        this.showFloatingText(this.player.x, this.player.y - 20, `-${amount} HP`, '#ef4444');
        this.updateHUD();

        if (this.playerHp <= 0) {
            this.handlePlayerDeath();
        }
    }

    handlePlayerDeath() {
        this.isGameOver = true;
        this.player.setVelocity(0, 0);
        this.player.setTint(0xff0000);
        window.soundEngine.playEnemyDeath();

        this.add.text(this.cameras.main.midPoint.x, this.cameras.main.midPoint.y - 30, 'ВЫ ПОГИБЛИ', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '24px',
            color: '#ef4444'
        }).setOrigin(0.5).setDepth(200);

        this.add.text(this.cameras.main.midPoint.x, this.cameras.main.midPoint.y + 15, 'Возрождение...', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '11px',
            color: '#cbd5e1'
        }).setOrigin(0.5).setDepth(200);

        this.time.delayedCall(1600, () => {
            this.scene.restart();
        });
    }

    // ----------------------------------------------------
    // COLLISIONS & OVERLAPS
    // ----------------------------------------------------
    setupCollisions() {
        // Player & Environment
        this.physics.add.collider(this.player, this.platforms, () => {
            if (this.player.body.touching.down) {
                this.lastSafeX = this.player.x;
                this.lastSafeY = this.player.y;
            }
        });
        this.physics.add.collider(this.player, this.woodPlatforms);

        // Skeletons & Environment
        this.physics.add.collider(this.skeletons, this.platforms);
        this.physics.add.collider(this.skeletons, this.woodPlatforms);

        // Coins physics
        this.physics.add.collider(this.coins, this.platforms);
        this.physics.add.collider(this.coins, this.woodPlatforms);

        // Player collects coins
        this.physics.add.overlap(this.player, this.coins, (player, coin) => {
            coin.destroy();
            this.coinsCollected++;
            window.gameState.coins = this.coinsCollected;
            window.soundEngine.playCoin();
            this.showFloatingText(coin.x, coin.y - 10, '+1 🪙', '#ffd700');
            this.updateHUD();
        });

        // Player touches spikes (peril hazard)
        this.physics.add.overlap(this.player, this.spikes, () => {
            this.damagePlayer(25, this.player.x);
            // Respawn back onto last safe ledge
            this.player.setPosition(this.lastSafeX, this.lastSafeY - 10);
            this.player.setVelocity(0, 0);
        });

        // Arrow Collisions
        this.physics.add.collider(this.arrows, this.platforms, (arrow) => arrow.destroy());
        this.physics.add.collider(this.arrows, this.woodPlatforms, (arrow) => arrow.destroy());
        this.physics.add.overlap(this.arrows, this.skeletons, (arrow, skel) => {
            arrow.destroy();
            this.damageSkeleton(skel, 35, arrow.x);
        });

        // Fireball Collisions
        this.physics.add.collider(this.fireballs, this.platforms, (fb) => {
            this.createExplosion(fb.x, fb.y);
            fb.destroy();
        });
        this.physics.add.overlap(this.fireballs, this.skeletons, (fb, skel) => {
            this.createExplosion(fb.x, fb.y);
            fb.destroy();
            this.damageSkeleton(skel, 55, fb.x);
        });
    }

    createExplosion(x, y) {
        window.soundEngine.playFireball();
        for (let i = 0; i < 8; i++) {
            const spark = this.add.image(x, y, 'particle_spark').setTint(0xff5500);
            this.tweens.add({
                targets: spark,
                x: x + Phaser.Math.Between(-25, 25),
                y: y + Phaser.Math.Between(-25, 25),
                alpha: 0,
                scale: 1.8,
                duration: 400,
                onComplete: () => spark.destroy()
            });
        }
    }

    // ----------------------------------------------------
    // INPUTS & CONTROLS BINDING
    // ----------------------------------------------------
    setupInputs() {
        this.cursors = this.input.keyboard.createCursorKeys();
        this.keys = this.input.keyboard.addKeys({
            W: Phaser.Input.Keyboard.KeyCodes.W,
            A: Phaser.Input.Keyboard.KeyCodes.A,
            S: Phaser.Input.Keyboard.KeyCodes.S,
            D: Phaser.Input.Keyboard.KeyCodes.D,
            E: Phaser.Input.Keyboard.KeyCodes.E,
            Q: Phaser.Input.Keyboard.KeyCodes.Q,
            SPACE: Phaser.Input.Keyboard.KeyCodes.SPACE,
            ONE: Phaser.Input.Keyboard.KeyCodes.ONE,
            TWO: Phaser.Input.Keyboard.KeyCodes.TWO,
            THREE: Phaser.Input.Keyboard.KeyCodes.THREE
        });

        // Mouse click or touch tap on canvas -> attack, shoot or jump
        this.input.on('pointerdown', (pointer) => {
            if (this.inCutscene || this.isGameOver) return;

            // Right click: quick weapon cycle
            if (pointer.rightButtonDown()) {
                this.switchWeaponNext();
                return;
            }

            // Direct tap logic on canvas (for mobile and mouse convenience)
            const onGround = this.player.body.blocked.down || this.player.body.touching.down;
            // If tapped in upper portion of canvas and player is on ground, trigger jump!
            if (pointer.y < this.scale.height * 0.42 && onGround) {
                this.player.setVelocityY(-450);
                window.soundEngine.playJump();
                this.player.play(`${this.currentArmor}_jump`, true);
            } else {
                this.performAttack();
            }
        });

        // Weapon hotkeys
        this.keys.Q.on('down', () => this.switchWeaponNext());
        this.keys.ONE.on('down', () => { this.activeWeapon = 'sword'; this.updateHUD(); });
        this.keys.TWO.on('down', () => {
            if (this.weaponsUnlocked.bow) { this.activeWeapon = 'bow'; this.updateHUD(); }
        });
        this.keys.THREE.on('down', () => {
            if (this.weaponsUnlocked.staff) { this.activeWeapon = 'staff'; this.updateHUD(); }
        });

        // Interact hotkey (E)
        this.keys.E.on('down', () => this.checkInteraction());
        this.keys.W.on('down', () => this.checkInteraction());
    }

    bindVirtualTouchControls() {
        const bindBtn = (id, keyName, isPulse = false, pulseCallback = null) => {
            const btn = document.getElementById(id);
            if (!btn) return;

            const handleDown = (e) => {
                e.preventDefault();
                btn.classList.add('active');
                if (isPulse && pulseCallback) {
                    pulseCallback();
                } else {
                    window.mobileInput[keyName] = true;
                }
            };

            const handleUp = (e) => {
                e.preventDefault();
                btn.classList.remove('active');
                if (!isPulse) {
                    window.mobileInput[keyName] = false;
                }
            };

            btn.addEventListener('pointerdown', handleDown, { passive: false });
            btn.addEventListener('pointerup', handleUp, { passive: false });
            btn.addEventListener('pointerleave', handleUp, { passive: false });
            btn.addEventListener('pointercancel', handleUp, { passive: false });
        };

        bindBtn('btn-left', 'left');
        bindBtn('btn-right', 'right');
        bindBtn('btn-jump', 'jump');
        bindBtn('btn-attack', 'attack', true, () => this.performAttack());
        bindBtn('btn-weapon', 'switchWeapon', true, () => this.switchWeaponNext());
        bindBtn('btn-interact', 'interact', true, () => this.checkInteraction());
    }

    checkInteraction() {
        // Find nearest chest
        this.chests.children.iterate((chest) => {
            if (!chest || chest.opened) return;
            const dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, chest.x, chest.y);
            if (dist < 48) {
                this.openChest(chest);
            }
        });
    }

    // ----------------------------------------------------
    // HUD & UI OVERLAY
    // ----------------------------------------------------
    createHUD() {
        this.hudContainer = this.add.container(0, 0).setScrollFactor(0).setDepth(100);

        // Top bar background
        const hudBg = this.add.rectangle(400, 20, 800, 40, 0x0f172a, 0.85);
        this.hudContainer.add(hudBg);

        // Health Bar container
        this.hpBarGfx = this.add.graphics();
        this.hudContainer.add(this.hpBarGfx);

        this.hpLabel = this.add.text(18, 12, 'HP: 100/100', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '9px',
            color: '#ffffff'
        });
        this.hudContainer.add(this.hpLabel);

        // Armor badge
        this.armorLabel = this.add.text(170, 12, `[🛡 ${this.armorName}]`, {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '8px',
            color: '#94a3b8'
        });
        this.hudContainer.add(this.armorLabel);

        // Weapon Selector text
        this.weaponLabel = this.add.text(400, 12, 'ОРУЖИЕ: ⚔ МЕЧ', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '9px',
            color: '#facc15'
        }).setOrigin(0.5, 0);
        this.hudContainer.add(this.weaponLabel);

        // Coins counter
        this.coinsLabel = this.add.text(620, 12, '🪙 00', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '9px',
            color: '#ffd700'
        });
        this.hudContainer.add(this.coinsLabel);

        // Chests counter
        this.chestsLabel = this.add.text(710, 12, '🗝 0/4', {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '9px',
            color: '#38bdf8'
        });
        this.hudContainer.add(this.chestsLabel);

        this.updateHUD();
    }

    updateHUD() {
        // Redraw HP bar
        this.hpBarGfx.clear();
        this.hpBarGfx.fillStyle(0x334155, 1);
        this.hpBarGfx.fillRect(16, 26, 130, 8);

        const hpRatio = Math.max(0, this.playerHp / this.playerMaxHp);
        const hpColor = (hpRatio > 0.5) ? 0x22c55e : (hpRatio > 0.25 ? 0xeab308 : 0xef4444);
        this.hpBarGfx.fillStyle(hpColor, 1);
        this.hpBarGfx.fillRect(16, 26, 130 * hpRatio, 8);

        this.hpLabel.setText(`HP: ${this.playerHp}/${this.playerMaxHp}`);
        this.armorLabel.setText(`[🛡 ${this.armorName}]`);

        const weaponIcons = {
            sword: '⚔ МЕЧ',
            bow: '🏹 ЛУК',
            staff: '🔮 ПОСОХ'
        };
        this.weaponLabel.setText(`ОРУЖИЕ: ${weaponIcons[this.activeWeapon]}`);
        this.coinsLabel.setText(`🪙 ${this.coinsCollected < 10 ? '0' + this.coinsCollected : this.coinsCollected}`);
        this.chestsLabel.setText(`🗝 ${this.chestsOpened}/${window.gameState.totalChests}`);
    }

    showFloatingText(x, y, text, color = '#ffffff') {
        const txt = this.add.text(x, y, text, {
            fontFamily: '"Press Start 2P", monospace',
            fontSize: '8px',
            color: color
        }).setOrigin(0.5).setDepth(90);

        this.tweens.add({
            targets: txt,
            y: y - 28,
            alpha: 0,
            duration: 1200,
            ease: 'Power1',
            onComplete: () => txt.destroy()
        });
    }

    // ----------------------------------------------------
    // MAIN UPDATE LOOP
    // ----------------------------------------------------
    update(time, delta) {
        if (this.isGameOver) return;

        // Invulnerability Blinking
        if (this.isInvulnerable) {
            this.invulnerableTimer--;
            this.player.setAlpha((this.invulnerableTimer % 6 < 3) ? 0.3 : 1);
            if (this.invulnerableTimer <= 0) {
                this.isInvulnerable = false;
                this.player.setAlpha(1);
            }
        }

        // Check Cutscene Trigger
        if (!this.inCutscene && this.player.x >= this.cutsceneTriggerX) {
            this.startTowerCutscene();
            return;
        }

        // If in cutscene, freeze player controls
        if (this.inCutscene) {
            return;
        }

        // Fall into pit hazard check
        if (this.player.y > this.levelHeight + 40) {
            this.damagePlayer(25, this.player.x);
            this.player.setPosition(this.lastSafeX, this.lastSafeY - 10);
            this.player.setVelocity(0, 0);
            return;
        }

        // Skeleton AI update
        this.updateSkeletonAI();

        // ------------------------------------------------
        // PLAYER PLATFORMER PHYSICS (Mario-style feel)
        // ------------------------------------------------
        const onGround = this.player.body.blocked.down || this.player.body.touching.down;

        if (onGround) {
            this.coyoteCounter = 8; // 8 frames of coyote forgiveness
        } else {
            if (this.coyoteCounter > 0) this.coyoteCounter--;
        }

        // Horizontal Movement Input (Keyboard or Mobile Touch)
        const moveLeft = this.cursors.left.isDown || this.keys.A.isDown || window.mobileInput.left;
        const moveRight = this.cursors.right.isDown || this.keys.D.isDown || window.mobileInput.right;
        const jumpPressed = Phaser.Input.Keyboard.JustDown(this.cursors.up) ||
                            Phaser.Input.Keyboard.JustDown(this.keys.W) ||
                            Phaser.Input.Keyboard.JustDown(this.keys.SPACE) ||
                            window.mobileInput.jump;

        const jumpHeld = this.cursors.up.isDown || this.keys.W.isDown || this.keys.SPACE.isDown || window.mobileInput.jump;

        const runSpeed = (this.currentArmor === 'hero_gold') ? 225 : (this.currentArmor === 'hero_iron' ? 205 : 190);

        const curAnimKey = this.player.anims.currentAnim ? this.player.anims.currentAnim.key : '';
        const isBusyWithAction = curAnimKey.includes('attack') || curAnimKey.includes('bow') || curAnimKey.includes('hurt');

        if (moveLeft) {
            this.player.setVelocityX(-runSpeed);
            this.player.setFlipX(true);
            this.facingDirection = -1;
            if (onGround && !isBusyWithAction) {
                this.player.play(`${this.currentArmor}_run`, true);
            }
        } else if (moveRight) {
            this.player.setVelocityX(runSpeed);
            this.player.setFlipX(false);
            this.facingDirection = 1;
            if (onGround && !isBusyWithAction) {
                this.player.play(`${this.currentArmor}_run`, true);
            }
        } else {
            this.player.setVelocityX(0);
            if (onGround && !isBusyWithAction) {
                this.player.play(`${this.currentArmor}_idle`, true);
            }
        }

        // Jump Execution with Coyote time
        if (jumpPressed && this.coyoteCounter > 0) {
            this.player.setVelocityY(-450);
            this.coyoteCounter = 0;
            window.soundEngine.playJump();
            if (!isBusyWithAction) {
                this.player.play(`${this.currentArmor}_jump`, true);
            }
        }

        // Mario-style Variable Jump Height: cut jump if released early
        if (!jumpHeld && this.player.body.velocity.y < -150) {
            this.player.setVelocityY(-150);
        }

        if (!onGround && !isBusyWithAction) {
            this.player.play(`${this.currentArmor}_jump`, true);
        }

        // ------------------------------------------------
        // RANGED AIMING CROSSHAIR & TRAJECTORY LINE
        // ------------------------------------------------
        this.aimTrajectory.clear();
        if (this.activeWeapon === 'bow' || this.activeWeapon === 'staff') {
            const pointer = this.input.activePointer;
            const worldPointer = this.cameras.main.getWorldPoint(pointer.x, pointer.y);

            this.crosshair.setVisible(true);
            this.crosshair.setPosition(worldPointer.x, worldPointer.y);

            // Draw dotted trajectory from player to crosshair
            const angle = Phaser.Math.Angle.Between(this.player.x, this.player.y, worldPointer.x, worldPointer.y);
            const isStaff = (this.activeWeapon === 'staff');

            this.aimTrajectory.lineStyle(1.5, isStaff ? 0xf59e0b : 0x38bdf8, 0.7);
            for (let d = 20; d < 180; d += 22) {
                const dotX = this.player.x + Math.cos(angle) * d;
                const dotY = this.player.y + Math.sin(angle) * d + (isStaff ? 0 : (d * d * 0.0012)); // gravity preview
                this.aimTrajectory.strokeCircle(dotX, dotY, 2);
            }
        } else {
            this.crosshair.setVisible(false);
        }
    }
}

// ==========================================
// GAME CONFIGURATION INITIALIZATION
// ==========================================
function startKingdomAdventure() {
    if (window.game) return;

    const config = {
        type: Phaser.AUTO,
        width: 800,
        height: 450,
        parent: 'canvas-container',
        pixelArt: true,
        roundPixels: true,
        scale: {
            mode: Phaser.Scale.FIT,
            autoCenter: Phaser.Scale.CENTER_BOTH
        },
        physics: {
            default: 'arcade',
            arcade: {
                gravity: { y: 760 },
                debug: false
            }
        },
        scene: [BootScene, MainMenuScene, CharSelectScene, GameScene]
    };

    window.game = new Phaser.Game(config);
}

if (document.readyState === 'complete' || document.readyState === 'interactive') {
    startKingdomAdventure();
} else {
    window.addEventListener('DOMContentLoaded', startKingdomAdventure);
    window.addEventListener('load', startKingdomAdventure);
}
