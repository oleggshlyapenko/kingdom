/**
 * Kingdom Adventure - Pixel Art Texture Generator
 * Generates all 16-bit / 8-bit style sprites, spritesheets, and tiles dynamically.
 */
class TextureGenerator {
    static generateAll(scene) {
        this.generateTiles(scene);
        this.generateItems(scene);
        this.generateEffects(scene);
        this.generateHeroSpritesheets(scene);
        this.generateSkeletonSpritesheet(scene);
        this.generatePrincessSpritesheet(scene);
        this.generateDragonSpritesheet(scene);
        this.generateDecorations(scene);
    }

    // Helper to create an offscreen canvas
    static createCanvas(width, height) {
        const c = document.createElement('canvas');
        c.width = width;
        c.height = height;
        const ctx = c.getContext('2d');
        ctx.imageSmoothingEnabled = false;
        return { canvas: c, ctx: ctx };
    }

    // Helper to set pixel or fill pixel rect
    static px(ctx, color, x, y, w = 1, h = 1) {
        ctx.fillStyle = color;
        ctx.fillRect(Math.floor(x), Math.floor(y), Math.floor(w), Math.floor(h));
    }

    // ==========================================
    // TILES & PLATFORMS
    // ==========================================
    static generateTiles(scene) {
        const TILE = 32;

        // 1. Grass Block
        const { canvas: grassCanvas, ctx: gCtx } = this.createCanvas(TILE, TILE);
        // Dirt base
        gCtx.fillStyle = '#654321';
        gCtx.fillRect(0, 0, TILE, TILE);
        // Dirt details & pebbles
        for (let i = 0; i < 20; i++) {
            const rx = (i * 7) % TILE;
            const ry = 8 + ((i * 11) % (TILE - 8));
            gCtx.fillStyle = i % 2 === 0 ? '#4e3319' : '#7b5329';
            gCtx.fillRect(rx, ry, 2, 2);
        }
        // Grass top layer
        gCtx.fillStyle = '#2d882d';
        gCtx.fillRect(0, 0, TILE, 8);
        gCtx.fillStyle = '#44aa44';
        gCtx.fillRect(0, 0, TILE, 4);
        // Grass hanging blades
        const blades = [0, 3, 5, 8, 12, 15, 18, 22, 25, 28, 30];
        blades.forEach((bx, idx) => {
            const bh = 5 + (idx % 4) * 2;
            gCtx.fillStyle = '#44aa44';
            gCtx.fillRect(bx, 4, 2, bh);
            gCtx.fillStyle = '#2d882d';
            gCtx.fillRect(bx, 4 + bh - 2, 2, 2);
        });
        scene.textures.addCanvas('tile_grass', grassCanvas);

        // 2. Dirt Block
        const { canvas: dirtCanvas, ctx: dCtx } = this.createCanvas(TILE, TILE);
        dCtx.fillStyle = '#654321';
        dCtx.fillRect(0, 0, TILE, TILE);
        for (let i = 0; i < 35; i++) {
            const rx = (i * 13) % TILE;
            const ry = (i * 17) % TILE;
            dCtx.fillStyle = i % 3 === 0 ? '#4a3016' : (i % 3 === 1 ? '#7a542b' : '#3d2510');
            dCtx.fillRect(rx, ry, (i % 2) + 2, (i % 2) + 2);
        }
        // Dark borders
        dCtx.fillStyle = '#40270f';
        dCtx.fillRect(0, 0, TILE, 1);
        dCtx.fillRect(0, TILE - 1, TILE, 1);
        dCtx.fillRect(0, 0, 1, TILE);
        dCtx.fillRect(TILE - 1, 0, 1, TILE);
        scene.textures.addCanvas('tile_dirt', dirtCanvas);

        // 3. Castle Stone Brick
        const { canvas: stoneCanvas, ctx: sCtx } = this.createCanvas(TILE, TILE);
        sCtx.fillStyle = '#555e69';
        sCtx.fillRect(0, 0, TILE, TILE);
        // Mortar lines
        sCtx.fillStyle = '#2f343b';
        sCtx.fillRect(0, 0, TILE, 2);
        sCtx.fillRect(0, 15, TILE, 2);
        sCtx.fillRect(0, 30, TILE, 2);
        sCtx.fillRect(15, 0, 2, 15);
        sCtx.fillRect(7, 16, 2, 15);
        sCtx.fillRect(23, 16, 2, 15);
        // Stone highlights
        sCtx.fillStyle = '#7a8594';
        sCtx.fillRect(1, 2, 14, 2);
        sCtx.fillRect(17, 2, 14, 2);
        sCtx.fillRect(1, 17, 6, 2);
        sCtx.fillRect(9, 17, 14, 2);
        sCtx.fillRect(25, 17, 6, 2);
        scene.textures.addCanvas('tile_stone', stoneCanvas);

        // 4. Wooden Platform (one-way bridge)
        const { canvas: woodCanvas, ctx: wCtx } = this.createCanvas(TILE, 16);
        wCtx.fillStyle = '#8b5a2b';
        wCtx.fillRect(0, 0, TILE, 16);
        // Wood grain
        wCtx.fillStyle = '#a06a35';
        wCtx.fillRect(0, 0, TILE, 4);
        wCtx.fillStyle = '#6b421a';
        wCtx.fillRect(0, 14, TILE, 2);
        wCtx.fillRect(10, 0, 2, 16);
        wCtx.fillRect(22, 0, 2, 16);
        // Nails
        wCtx.fillStyle = '#222';
        wCtx.fillRect(4, 5, 2, 2);
        wCtx.fillRect(16, 5, 2, 2);
        wCtx.fillRect(27, 5, 2, 2);
        scene.textures.addCanvas('tile_wood', woodCanvas);

        // 5. Spikes
        const { canvas: spikeCanvas, ctx: spCtx } = this.createCanvas(TILE, TILE);
        spCtx.clearRect(0, 0, TILE, TILE);
        for (let s = 0; s < 4; s++) {
            const bx = s * 8;
            spCtx.fillStyle = '#9aa5b1';
            spCtx.beginPath();
            spCtx.moveTo(bx + 4, 8);
            spCtx.lineTo(bx + 1, 32);
            spCtx.lineTo(bx + 7, 32);
            spCtx.closePath();
            spCtx.fill();
            // Highlight
            spCtx.fillStyle = '#e2e8f0';
            spCtx.beginPath();
            spCtx.moveTo(bx + 4, 8);
            spCtx.lineTo(bx + 4, 32);
            spCtx.lineTo(bx + 2, 32);
            spCtx.closePath();
            spCtx.fill();
            // Blood tip for peril
            spCtx.fillStyle = '#c53030';
            spCtx.fillRect(bx + 3, 10, 2, 3);
        }
        scene.textures.addCanvas('tile_spikes', spikeCanvas);

        // 6. Tower Brick (ornate)
        const { canvas: tbCanvas, ctx: tbCtx } = this.createCanvas(TILE, TILE);
        tbCtx.fillStyle = '#3a4454';
        tbCtx.fillRect(0, 0, TILE, TILE);
        tbCtx.fillStyle = '#232b38';
        tbCtx.fillRect(0, 0, TILE, 2);
        tbCtx.fillRect(0, 16, TILE, 2);
        tbCtx.fillRect(16, 0, 2, 16);
        tbCtx.fillRect(8, 16, 2, 16);
        tbCtx.fillRect(24, 16, 2, 16);
        // Royal gold accents
        tbCtx.fillStyle = '#e6af2e';
        tbCtx.fillRect(15, 15, 4, 4);
        scene.textures.addCanvas('tile_tower', tbCanvas);

        // 7. Tower Battlement (parapet)
        const { canvas: batCanvas, ctx: batCtx } = this.createCanvas(TILE, TILE);
        batCtx.clearRect(0, 0, TILE, TILE);
        batCtx.fillStyle = '#485568';
        batCtx.fillRect(0, 12, TILE, 20);
        batCtx.fillRect(0, 0, 12, 12);
        batCtx.fillRect(20, 0, 12, 12);
        // Highlights
        batCtx.fillStyle = '#7a8ba3';
        batCtx.fillRect(0, 0, 12, 3);
        batCtx.fillRect(20, 0, 12, 3);
        batCtx.fillRect(12, 12, 8, 2);
        scene.textures.addCanvas('tile_battlement', batCanvas);
    }

    // ==========================================
    // ITEMS & WEAPONS & CHESTS
    // ==========================================
    static generateItems(scene) {
        // 1. Chests: Closed & Open (32x32)
        const { canvas: chestCanvas, ctx: cCtx } = this.createCanvas(64, 32);
        // Frame 0: Closed
        cCtx.fillStyle = '#7a461d';
        cCtx.fillRect(4, 10, 24, 18);
        cCtx.fillStyle = '#9c5b26';
        cCtx.fillRect(4, 8, 24, 6);
        // Golden bands & lock
        cCtx.fillStyle = '#d4af37';
        cCtx.fillRect(4, 12, 24, 2);
        cCtx.fillRect(4, 24, 24, 2);
        cCtx.fillRect(8, 8, 2, 20);
        cCtx.fillRect(22, 8, 2, 20);
        // Lock keyhole
        cCtx.fillStyle = '#ffd700';
        cCtx.fillRect(14, 15, 4, 5);
        cCtx.fillStyle = '#111';
        cCtx.fillRect(15, 17, 2, 2);

        // Frame 1: Open with treasure
        const ox = 32;
        cCtx.fillStyle = '#5c3312';
        cCtx.fillRect(ox + 4, 14, 24, 14);
        cCtx.fillStyle = '#9c5b26';
        // Open lid tilted back
        cCtx.fillRect(ox + 4, 2, 24, 8);
        cCtx.fillStyle = '#d4af37';
        cCtx.fillRect(ox + 8, 2, 2, 8);
        cCtx.fillRect(ox + 22, 2, 2, 8);
        // Golden coins & gems spilling out
        cCtx.fillStyle = '#ffd700';
        cCtx.fillRect(ox + 6, 12, 20, 6);
        cCtx.fillStyle = '#ff3366';
        cCtx.fillRect(ox + 10, 11, 4, 4);
        cCtx.fillStyle = '#00e5ff';
        cCtx.fillRect(ox + 18, 12, 4, 3);

        scene.textures.addSpriteSheet('chest', chestCanvas, { frameWidth: 32, frameHeight: 32 });

        // 2. Animated Coin (16x16, 4 frames -> 64x16)
        const { canvas: coinCanvas, ctx: coinCtx } = this.createCanvas(64, 16);
        const coinWidths = [12, 8, 4, 8];
        for (let f = 0; f < 4; f++) {
            const cx = f * 16 + 8;
            const cw = coinWidths[f];
            coinCtx.fillStyle = '#e6af2e';
            coinCtx.fillRect(cx - cw / 2, 2, cw, 12);
            coinCtx.fillStyle = '#ffd700';
            coinCtx.fillRect(cx - (cw / 2 - 1), 3, Math.max(1, cw - 2), 10);
            if (cw > 4) {
                coinCtx.fillStyle = '#fff4a3';
                coinCtx.fillRect(cx - 1, 4, 2, 4);
            }
        }
        scene.textures.addSpriteSheet('coin', coinCanvas, { frameWidth: 16, frameHeight: 16 });

        // 3. Heart (Full & Empty) 16x16
        const { canvas: heartCanvas, ctx: hCtx } = this.createCanvas(32, 16);
        // Full Heart (Frame 0)
        hCtx.fillStyle = '#c53030';
        hCtx.beginPath();
        hCtx.moveTo(8, 14);
        hCtx.lineTo(2, 6);
        hCtx.arc(5, 5, 3.5, Math.PI, 0, false);
        hCtx.arc(11, 5, 3.5, Math.PI, 0, false);
        hCtx.closePath();
        hCtx.fill();
        // Highlight
        hCtx.fillStyle = '#feb2b2';
        hCtx.fillRect(4, 4, 2, 2);

        // Empty Heart (Frame 1)
        const hx = 16;
        hCtx.fillStyle = '#4a5568';
        hCtx.beginPath();
        hCtx.moveTo(hx + 8, 14);
        hCtx.lineTo(hx + 2, 6);
        hCtx.arc(hx + 5, 5, 3.5, Math.PI, 0, false);
        hCtx.arc(hx + 11, 5, 3.5, Math.PI, 0, false);
        hCtx.closePath();
        hCtx.fill();
        scene.textures.addSpriteSheet('heart', heartCanvas, { frameWidth: 16, frameHeight: 16 });

        // 4. Weapons & Icons
        // Iron Sword
        const { canvas: isCanvas, ctx: isCtx } = this.createCanvas(24, 24);
        isCtx.save();
        isCtx.translate(12, 12);
        isCtx.rotate(-Math.PI / 4);
        isCtx.fillStyle = '#cbd5e1';
        isCtx.fillRect(-2, -10, 4, 14);
        isCtx.fillStyle = '#f8fafc';
        isCtx.fillRect(-1, -10, 2, 14);
        isCtx.fillStyle = '#94a3b8';
        isCtx.fillRect(-5, 4, 10, 2);
        isCtx.fillStyle = '#78350f';
        isCtx.fillRect(-1, 6, 2, 5);
        isCtx.restore();
        scene.textures.addCanvas('weapon_sword_iron', isCanvas);

        // Golden Sword
        const { canvas: gsCanvas, ctx: gsCtx } = this.createCanvas(24, 24);
        gsCtx.save();
        gsCtx.translate(12, 12);
        gsCtx.rotate(-Math.PI / 4);
        gsCtx.fillStyle = '#f59e0b';
        gsCtx.fillRect(-2, -11, 4, 15);
        gsCtx.fillStyle = '#fef08a';
        gsCtx.fillRect(-1, -11, 2, 15);
        gsCtx.fillStyle = '#dc2626';
        gsCtx.fillRect(-6, 4, 12, 3);
        gsCtx.fillStyle = '#451a03';
        gsCtx.fillRect(-1, 7, 2, 5);
        gsCtx.restore();
        scene.textures.addCanvas('weapon_sword_gold', gsCanvas);

        // Bow
        const { canvas: bowCanvas, ctx: bCtx } = this.createCanvas(24, 24);
        bCtx.strokeStyle = '#854d0e';
        bCtx.lineWidth = 3;
        bCtx.beginPath();
        bCtx.arc(8, 12, 9, -Math.PI / 2.2, Math.PI / 2.2, false);
        bCtx.stroke();
        // Bowstring
        bCtx.strokeStyle = '#e2e8f0';
        bCtx.lineWidth = 1;
        bCtx.beginPath();
        bCtx.moveTo(11, 3);
        bCtx.lineTo(11, 21);
        bCtx.stroke();
        scene.textures.addCanvas('weapon_bow', bowCanvas);

        // Arrow
        const { canvas: arrCanvas, ctx: aCtx } = this.createCanvas(20, 8);
        aCtx.fillStyle = '#92400e';
        aCtx.fillRect(2, 3, 14, 2);
        // Arrowhead
        aCtx.fillStyle = '#e2e8f0';
        aCtx.beginPath();
        aCtx.moveTo(16, 1);
        aCtx.lineTo(20, 4);
        aCtx.lineTo(16, 7);
        aCtx.closePath();
        aCtx.fill();
        // Fletching
        aCtx.fillStyle = '#ef4444';
        aCtx.fillRect(0, 1, 3, 2);
        aCtx.fillRect(0, 5, 3, 2);
        scene.textures.addCanvas('projectile_arrow', arrCanvas);

        // Fire Staff
        const { canvas: stCanvas, ctx: stCtx } = this.createCanvas(24, 24);
        stCtx.fillStyle = '#581c87';
        stCtx.fillRect(10, 6, 4, 16);
        // Ruby Orb with glow
        stCtx.fillStyle = '#ff0055';
        stCtx.beginPath();
        stCtx.arc(12, 5, 5, 0, Math.PI * 2);
        stCtx.fill();
        stCtx.fillStyle = '#ffd1dc';
        stCtx.fillRect(10, 3, 2, 2);
        scene.textures.addCanvas('weapon_staff', stCanvas);

        // Fireball Projectile (16x16, 3 frames -> 48x16)
        const { canvas: fbCanvas, ctx: fbCtx } = this.createCanvas(48, 16);
        for (let f = 0; f < 3; f++) {
            const fx = f * 16 + 8;
            fbCtx.fillStyle = '#ea580c';
            fbCtx.beginPath();
            fbCtx.arc(fx, 8, 7, 0, Math.PI * 2);
            fbCtx.fill();
            fbCtx.fillStyle = '#facc15';
            fbCtx.beginPath();
            fbCtx.arc(fx, 8, 4 + (f % 2), 0, Math.PI * 2);
            fbCtx.fill();
            fbCtx.fillStyle = '#ffffff';
            fbCtx.fillRect(fx - 1, 7, 3, 2);
        }
        scene.textures.addSpriteSheet('projectile_fireball', fbCanvas, { frameWidth: 16, frameHeight: 16 });

        // Armor Item Icon
        const { canvas: armCanvas, ctx: armCtx } = this.createCanvas(24, 24);
        armCtx.fillStyle = '#475569';
        armCtx.fillRect(4, 4, 16, 16);
        armCtx.fillStyle = '#94a3b8';
        armCtx.fillRect(6, 6, 12, 12);
        armCtx.fillStyle = '#f1f5f9';
        armCtx.fillRect(7, 7, 4, 4);
        scene.textures.addCanvas('item_armor_iron', armCanvas);

        // Gold Armor Icon
        const { canvas: gaCanvas, ctx: gaCtx } = this.createCanvas(24, 24);
        gaCtx.fillStyle = '#d97706';
        gaCtx.fillRect(4, 4, 16, 16);
        gaCtx.fillStyle = '#fde047';
        gaCtx.fillRect(6, 6, 12, 12);
        gaCtx.fillStyle = '#ef4444';
        gaCtx.fillRect(10, 9, 4, 6);
        scene.textures.addCanvas('item_armor_gold', gaCanvas);
    }

    // ==========================================
    // COMBAT EFFECTS & PARTICLES
    // ==========================================
    static generateEffects(scene) {
        // Sword Slash Arcs (32x32, 3 frames -> 96x32)
        const { canvas: sCanvas, ctx: sCtx } = this.createCanvas(96, 32);
        for (let f = 0; f < 3; f++) {
            const ox = f * 32;
            sCtx.strokeStyle = f === 0 ? '#67e8f9' : (f === 1 ? '#ffffff' : '#a5f3fc');
            sCtx.lineWidth = 4 - f;
            sCtx.beginPath();
            sCtx.arc(ox + 16, 16, 13 + f * 2, -Math.PI / 3, Math.PI / 2);
            sCtx.stroke();
        }
        scene.textures.addSpriteSheet('fx_slash', sCanvas, { frameWidth: 32, frameHeight: 32 });

        // Crosshair
        const { canvas: crossCanvas, ctx: crCtx } = this.createCanvas(24, 24);
        crCtx.strokeStyle = '#ef4444';
        crCtx.lineWidth = 2;
        crCtx.beginPath();
        crCtx.arc(12, 12, 7, 0, Math.PI * 2);
        crCtx.stroke();
        crCtx.fillStyle = '#ef4444';
        crCtx.fillRect(11, 2, 2, 4);
        crCtx.fillRect(11, 18, 2, 4);
        crCtx.fillRect(2, 11, 4, 2);
        crCtx.fillRect(18, 11, 4, 2);
        crCtx.fillRect(11, 11, 2, 2);
        scene.textures.addCanvas('crosshair', crossCanvas);

        // Sparkle / Dust Particle
        const { canvas: pCanvas, ctx: pCtx } = this.createCanvas(8, 8);
        pCtx.fillStyle = '#ffd700';
        pCtx.fillRect(2, 0, 4, 8);
        pCtx.fillRect(0, 2, 8, 4);
        pCtx.fillStyle = '#ffffff';
        pCtx.fillRect(2, 2, 4, 4);
        scene.textures.addCanvas('particle_spark', pCanvas);
    }

    // ==========================================
    // HERO SPRITESHEETS (Tunic, Iron Armor, Golden Armor)
    // ==========================================
    // 32x32 per frame:
    // Frame 0-3: Idle (4 frames)
    // Frame 4-7: Run (4 frames)
    // Frame 8: Jump
    // Frame 9-11: Sword Attack (3 frames)
    // Frame 12-14: Bow Aim & Shoot (3 frames)
    // Frame 15: Hurt
    // Total: 16 frames = 512x32 canvas
    static generateHeroSpritesheets(scene) {
        const armorTiers = [
            { id: 'hero_tunic', tunicColor: '#2b6cb0', trimColor: '#854d0e', armorName: 'Стартовая туника', helmet: false, cape: false },
            { id: 'hero_iron', tunicColor: '#64748b', trimColor: '#94a3b8', armorName: 'Железные латы', helmet: true, helmetColor: '#94a3b8', cape: false },
            { id: 'hero_gold', tunicColor: '#d97706', trimColor: '#facc15', armorName: 'Золотой доспех паладина', helmet: true, helmetColor: '#facc15', cape: true }
        ];

        armorTiers.forEach(tier => {
            const { canvas, ctx } = this.createCanvas(512, 32);

            for (let f = 0; f < 16; f++) {
                const ox = f * 32;
                this.drawHeroFrame(ctx, ox, f, tier);
            }

            scene.textures.addSpriteSheet(tier.id, canvas, { frameWidth: 32, frameHeight: 32 });
        });
    }

    static drawHeroFrame(ctx, ox, frameIdx, tier) {
        // Skin & Hair colors
        const skinColor = '#ffdbac';
        const skinShadow = '#e0ac69';
        const hairColor = '#6b4423';
        const hairHighlight = '#8d5b32';
        const eyesColor = '#1e293b';
        const bootsColor = '#451a03';

        let bobY = 0;
        let legL = 0;
        let legR = 0;
        let armPose = 'idle'; // 'idle', 'run', 'attack1', 'attack2', 'attack3', 'bow1', 'bow2', 'bow3', 'hurt'
        let hurtFlash = false;

        if (frameIdx >= 0 && frameIdx <= 3) {
            // Idle
            bobY = (frameIdx === 1 || frameIdx === 2) ? 1 : 0;
            armPose = 'idle';
        } else if (frameIdx >= 4 && frameIdx <= 7) {
            // Run
            const runOffsets = [
                { bob: 0, l: -3, r: 3 },
                { bob: -1, l: 0, r: 0 },
                { bob: 0, l: 3, r: -3 },
                { bob: -1, l: 0, r: 0 }
            ];
            const ro = runOffsets[frameIdx - 4];
            bobY = ro.bob;
            legL = ro.l;
            legR = ro.r;
            armPose = 'run';
        } else if (frameIdx === 8) {
            // Jump
            bobY = -2;
            legL = -2;
            legR = 2;
            armPose = 'jump';
        } else if (frameIdx >= 9 && frameIdx <= 11) {
            // Sword Attack
            bobY = 0;
            armPose = `attack${frameIdx - 8}`;
        } else if (frameIdx >= 12 && frameIdx <= 14) {
            // Bow Shoot
            bobY = 0;
            armPose = `bow${frameIdx - 11}`;
        } else if (frameIdx === 15) {
            // Hurt
            bobY = 1;
            hurtFlash = true;
            armPose = 'hurt';
        }

        const headX = ox + 16;
        const headY = 9 + bobY;

        // Cape (Gold tier)
        if (tier.cape) {
            ctx.fillStyle = hurtFlash ? '#ff0000' : '#b91c1c';
            ctx.fillRect(headX - 7, headY + 5, 4, 13);
            ctx.fillStyle = '#dc2626';
            ctx.fillRect(headX - 6, headY + 6, 2, 11);
        }

        // --- Legs & Boots ---
        ctx.fillStyle = hurtFlash ? '#ff8888' : '#1e293b'; // Trousers
        ctx.fillRect(headX - 4 + legL, headY + 12, 3, 5);
        ctx.fillRect(headX + 1 + legR, headY + 12, 3, 5);

        // Boots
        ctx.fillStyle = hurtFlash ? '#ffffff' : bootsColor;
        ctx.fillRect(headX - 5 + legL, headY + 17, 4, 4);
        ctx.fillRect(headX + 1 + legR, headY + 17, 4, 4);

        // --- Body / Armor / Tunic ---
        ctx.fillStyle = hurtFlash ? '#ff4444' : tier.tunicColor;
        ctx.fillRect(headX - 4, headY + 5, 8, 8);

        // Belt & Buckle
        ctx.fillStyle = hurtFlash ? '#ffffff' : '#3e2723';
        ctx.fillRect(headX - 4, headY + 10, 8, 2);
        ctx.fillStyle = hurtFlash ? '#ff0000' : tier.trimColor;
        ctx.fillRect(headX - 1, headY + 10, 2, 2);

        // Shoulder Pauldrons / Trim
        ctx.fillStyle = hurtFlash ? '#ffffff' : tier.trimColor;
        ctx.fillRect(headX - 5, headY + 5, 2, 3);
        ctx.fillRect(headX + 3, headY + 5, 2, 3);

        // --- Head & Face (White guy, short hair) ---
        ctx.fillStyle = hurtFlash ? '#ffaaaa' : skinColor;
        ctx.fillRect(headX - 3, headY - 3, 6, 7);
        // Face shadow
        ctx.fillStyle = hurtFlash ? '#ff6666' : skinShadow;
        ctx.fillRect(headX - 3, headY + 3, 6, 1);

        // Eyes
        ctx.fillStyle = hurtFlash ? '#ffffff' : eyesColor;
        ctx.fillRect(headX, headY - 1, 2, 2);

        // Short Haircut (Brown stylish crop)
        if (!tier.helmet) {
            ctx.fillStyle = hurtFlash ? '#ff0000' : hairColor;
            ctx.fillRect(headX - 4, headY - 5, 8, 3); // top
            ctx.fillRect(headX - 4, headY - 2, 2, 3); // back
            ctx.fillRect(headX - 1, headY - 4, 4, 2); // fringe
            // Hair highlight
            ctx.fillStyle = hairHighlight;
            ctx.fillRect(headX - 2, headY - 5, 4, 1);
        } else {
            // Knight Helmet
            ctx.fillStyle = hurtFlash ? '#ffffff' : tier.helmetColor;
            ctx.fillRect(headX - 4, headY - 6, 8, 4);
            ctx.fillRect(headX - 4, headY - 2, 3, 4);
            // Visor / plume
            ctx.fillStyle = tier.trimColor;
            ctx.fillRect(headX - 1, headY - 7, 3, 2);
            ctx.fillRect(headX - 1, headY - 2, 4, 1);
        }

        // --- Arms, Weapons & Actions ---
        if (armPose === 'idle') {
            // Resting arms
            ctx.fillStyle = hurtFlash ? '#ffaaaa' : skinColor;
            ctx.fillRect(headX - 5, headY + 6, 2, 5);
            ctx.fillRect(headX + 3, headY + 6, 2, 5);
            // Sheathed sword on hip
            ctx.fillStyle = '#94a3b8';
            ctx.fillRect(headX - 7, headY + 7, 2, 7);
        } else if (armPose === 'run') {
            // Running arms swing
            ctx.fillStyle = hurtFlash ? '#ffaaaa' : skinColor;
            ctx.fillRect(headX - 5 + legR, headY + 6, 2, 4);
            ctx.fillRect(headX + 3 + legL, headY + 6, 2, 4);
        } else if (armPose === 'jump') {
            // Arms raised
            ctx.fillStyle = hurtFlash ? '#ffaaaa' : skinColor;
            ctx.fillRect(headX - 6, headY + 3, 2, 5);
            ctx.fillRect(headX + 4, headY + 3, 2, 5);
        } else if (armPose === 'attack1') {
            // Sword windup back
            ctx.fillStyle = skinColor;
            ctx.fillRect(headX - 6, headY + 3, 3, 3);
            ctx.fillStyle = '#cbd5e1';
            ctx.fillRect(headX - 9, headY - 4, 3, 9);
        } else if (armPose === 'attack2') {
            // Full sword slash forward
            ctx.fillStyle = skinColor;
            ctx.fillRect(headX + 4, headY + 5, 4, 3);
            // Drawn blade extending out
            ctx.fillStyle = '#cbd5e1';
            ctx.fillRect(headX + 8, headY + 5, 9, 3);
            ctx.fillStyle = '#f8fafc';
            ctx.fillRect(headX + 17, headY + 6, 2, 1);
        } else if (armPose === 'attack3') {
            // Follow-through downward cut
            ctx.fillStyle = skinColor;
            ctx.fillRect(headX + 4, headY + 7, 3, 3);
            ctx.fillStyle = '#cbd5e1';
            ctx.fillRect(headX + 6, headY + 9, 3, 9);
        } else if (armPose === 'bow1') {
            // Raising bow
            ctx.fillStyle = skinColor;
            ctx.fillRect(headX + 3, headY + 5, 4, 3);
            ctx.fillStyle = '#854d0e';
            ctx.fillRect(headX + 7, headY + 2, 2, 9);
        } else if (armPose === 'bow2') {
            // Full draw
            ctx.fillStyle = skinColor;
            ctx.fillRect(headX - 3, headY + 5, 3, 3);
            ctx.fillRect(headX + 4, headY + 5, 4, 3);
            ctx.fillStyle = '#854d0e';
            ctx.fillRect(headX + 8, headY + 1, 2, 11);
            // Arrow knocked
            ctx.fillStyle = '#ef4444';
            ctx.fillRect(headX + 2, headY + 6, 7, 2);
        } else if (armPose === 'bow3') {
            // Release recoil
            ctx.fillStyle = skinColor;
            ctx.fillRect(headX + 4, headY + 5, 4, 3);
            ctx.fillStyle = '#854d0e';
            ctx.fillRect(headX + 9, headY + 2, 2, 9);
        } else if (armPose === 'hurt') {
            // Recoil
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(headX - 6, headY + 4, 3, 3);
            ctx.fillRect(headX + 3, headY + 4, 3, 3);
        }
    }

    // ==========================================
    // SKELETON SPRITESHEET
    // ==========================================
    // 32x32 per frame:
    // 0-3: Walk (4 frames)
    // 4-5: Attack (2 frames)
    // 6: Hurt
    // 7: Shatter / Die
    // Total: 8 frames = 256x32 canvas
    static generateSkeletonSpritesheet(scene) {
        const { canvas, ctx } = this.createCanvas(256, 32);

        for (let f = 0; f < 8; f++) {
            const ox = f * 32;
            const boneColor = '#e2e8f0';
            const boneDark = '#94a3b8';
            const redEye = '#ef4444';

            let legL = 0;
            let legR = 0;
            let armAction = 'idle';

            if (f < 4) {
                // Walk cycle
                const wo = [{ l: -2, r: 2 }, { l: 0, r: 0 }, { l: 2, r: -2 }, { l: 0, r: 0 }];
                legL = wo[f].l;
                legR = wo[f].r;
            } else if (f === 4 || f === 5) {
                armAction = f === 4 ? 'windup' : 'slash';
            }

            if (f === 7) {
                // Shatter into bone pieces on ground
                ctx.fillStyle = boneColor;
                ctx.fillRect(ox + 8, 26, 4, 3);
                ctx.fillRect(ox + 14, 25, 5, 4);
                ctx.fillRect(ox + 21, 27, 4, 2);
                ctx.fillRect(ox + 16, 20, 6, 5); // broken skull
                ctx.fillStyle = redEye;
                ctx.fillRect(ox + 19, 21, 1, 1);
                continue;
            }

            const hx = ox + 16;
            const hy = 10;

            // Skull
            ctx.fillStyle = (f === 6) ? '#ff5555' : boneColor;
            ctx.fillRect(hx - 3, hy - 4, 6, 6);
            ctx.fillRect(hx - 2, hy + 2, 4, 2); // jaw

            // Glowing Evil Eye Sockets
            ctx.fillStyle = '#0f172a';
            ctx.fillRect(hx - 2, hy - 2, 2, 2);
            ctx.fillRect(hx + 1, hy - 2, 2, 2);
            ctx.fillStyle = redEye;
            ctx.fillRect(hx - 1, hy - 2, 1, 1);
            ctx.fillRect(hx + 2, hy - 2, 1, 1);

            // Spine & Ribs
            ctx.fillStyle = boneDark;
            ctx.fillRect(hx - 1, hy + 4, 2, 7);
            ctx.fillStyle = boneColor;
            ctx.fillRect(hx - 3, hy + 5, 6, 1); // rib 1
            ctx.fillRect(hx - 4, hy + 7, 8, 1); // rib 2
            ctx.fillRect(hx - 3, hy + 9, 6, 1); // rib 3

            // Ragged loincloth
            ctx.fillStyle = '#581c87';
            ctx.fillRect(hx - 3, hy + 11, 6, 3);

            // Legs
            ctx.fillStyle = boneColor;
            ctx.fillRect(hx - 3 + legL, hy + 13, 2, 7);
            ctx.fillRect(hx + 1 + legR, hy + 13, 2, 7);

            // Feet
            ctx.fillRect(hx - 4 + legL, hy + 19, 3, 2);
            ctx.fillRect(hx + 1 + legR, hy + 19, 3, 2);

            // Arms & Rusted Sword
            if (armAction === 'idle') {
                ctx.fillStyle = boneColor;
                ctx.fillRect(hx - 5, hy + 5, 2, 5);
                ctx.fillRect(hx + 3, hy + 5, 2, 5);
                // Rusted bone blade held down
                ctx.fillStyle = '#b45309';
                ctx.fillRect(hx + 4, hy + 8, 2, 7);
            } else if (armAction === 'windup') {
                ctx.fillStyle = boneColor;
                ctx.fillRect(hx - 6, hy + 2, 2, 5);
                ctx.fillStyle = '#b45309';
                ctx.fillRect(hx - 8, hy - 4, 2, 8);
            } else if (armAction === 'slash') {
                ctx.fillStyle = boneColor;
                ctx.fillRect(hx + 4, hy + 4, 5, 2);
                ctx.fillStyle = '#b45309';
                ctx.fillRect(hx + 8, hy + 4, 8, 3);
            }
        }

        scene.textures.addSpriteSheet('skeleton', canvas, { frameWidth: 32, frameHeight: 32 });
    }

    // ==========================================
    // PRINCESS SPRITESHEET
    // ==========================================
    // 32x32 per frame:
    // 0: Idle
    // 1-2: Wave / Cry for Help
    // 3: Shocked
    // Total: 4 frames = 128x32 canvas
    static generatePrincessSpritesheet(scene) {
        const { canvas, ctx } = this.createCanvas(128, 32);

        for (let f = 0; f < 4; f++) {
            const ox = f * 32;
            const hx = ox + 16;
            const hy = 11;

            // Flowing Pink Royal Gown
            ctx.fillStyle = '#ec4899';
            ctx.beginPath();
            ctx.moveTo(hx - 2, hy + 5);
            ctx.lineTo(hx + 2, hy + 5);
            ctx.lineTo(hx + 7, hy + 18);
            ctx.lineTo(hx - 7, hy + 18);
            ctx.closePath();
            ctx.fill();

            // Gown white lace trim
            ctx.fillStyle = '#fdf2f8';
            ctx.fillRect(hx - 1, hy + 6, 2, 8);
            ctx.fillRect(hx - 7, hy + 18, 14, 2);

            // Face & Neck
            ctx.fillStyle = '#ffdbac';
            ctx.fillRect(hx - 3, hy - 3, 6, 7);
            // Blue eyes
            ctx.fillStyle = '#0284c7';
            ctx.fillRect(hx - 2, hy - 1, 1, 2);
            ctx.fillRect(hx + 1, hy - 1, 1, 2);
            // Pink smile / gasp
            ctx.fillStyle = '#f43f5e';
            if (f === 3) {
                ctx.fillRect(hx - 1, hy + 2, 2, 2); // open mouth gasp
            } else {
                ctx.fillRect(hx - 1, hy + 2, 2, 1);
            }

            // Long Golden Blonde Hair
            ctx.fillStyle = '#fde047';
            ctx.fillRect(hx - 5, hy - 5, 10, 4); // crown hair
            ctx.fillRect(hx - 5, hy - 1, 2, 10); // left flowing lock
            ctx.fillRect(hx + 3, hy - 1, 2, 10); // right flowing lock

            // Golden Tiara with Ruby
            ctx.fillStyle = '#eab308';
            ctx.fillRect(hx - 3, hy - 7, 6, 2);
            ctx.fillRect(hx - 1, hy - 8, 2, 2);
            ctx.fillStyle = '#dc2626';
            ctx.fillRect(hx, hy - 7, 1, 1);

            // Arms & Gestures
            ctx.fillStyle = '#ffdbac';
            if (f === 0) {
                // Hands clasped gracefully
                ctx.fillRect(hx - 2, hy + 7, 4, 3);
            } else if (f === 1) {
                // Left hand waving high
                ctx.fillRect(hx - 5, hy + 2, 2, 5);
                ctx.fillRect(hx - 6, hy, 2, 3);
                ctx.fillRect(hx + 1, hy + 7, 3, 2);
            } else if (f === 2) {
                // Wave tilted other way
                ctx.fillRect(hx - 6, hy - 2, 2, 4);
                ctx.fillRect(hx + 1, hy + 7, 3, 2);
            } else if (f === 3) {
                // Hands on cheeks terrified
                ctx.fillRect(hx - 5, hy, 2, 4);
                ctx.fillRect(hx + 3, hy, 2, 4);
            }
        }

        scene.textures.addSpriteSheet('princess', canvas, { frameWidth: 32, frameHeight: 32 });
    }

    // ==========================================
    // GIANT RED DRAGON SPRITESHEET
    // ==========================================
    // 96x80 per frame:
    // 0: Wings Up (Gliding)
    // 1: Wings Down (Flapping)
    // 2: Roaring with fire breath glow
    // Total: 3 frames = 288x80 canvas
    static generateDragonSpritesheet(scene) {
        const { canvas, ctx } = this.createCanvas(288, 80);

        for (let f = 0; f < 3; f++) {
            const ox = f * 96;
            const cx = ox + 48;
            const cy = 42;

            // Dragon Body (Dark Crimson)
            ctx.fillStyle = '#991b1b';
            ctx.beginPath();
            ctx.ellipse(cx, cy, 22, 14, 0, 0, Math.PI * 2);
            ctx.fill();

            // Fiery Underbelly scales
            ctx.fillStyle = '#f97316';
            ctx.beginPath();
            ctx.ellipse(cx + 4, cy + 4, 14, 8, 0, 0, Math.PI * 2);
            ctx.fill();

            // Long Spiked Tail
            ctx.fillStyle = '#991b1b';
            ctx.beginPath();
            ctx.moveTo(cx - 18, cy);
            ctx.quadraticCurveTo(cx - 38, cy - 8, cx - 44, cy + 12);
            ctx.lineTo(cx - 36, cy + 14);
            ctx.quadraticCurveTo(cx - 30, cy + 4, cx - 14, cy + 8);
            ctx.closePath();
            ctx.fill();

            // Tail barb / spade
            ctx.fillStyle = '#450a0a';
            ctx.beginPath();
            ctx.moveTo(cx - 44, cy + 12);
            ctx.lineTo(cx - 48, cy + 6);
            ctx.lineTo(cx - 40, cy + 7);
            ctx.closePath();
            ctx.fill();

            // Dragon Head & Neck
            ctx.fillStyle = '#b91c1c';
            ctx.beginPath();
            ctx.moveTo(cx + 14, cy - 4);
            ctx.lineTo(cx + 26, cy - 14);
            ctx.lineTo(cx + 42, cy - 10);
            ctx.lineTo(cx + 44, cy - 2);
            ctx.lineTo(cx + 32, cy + 4);
            ctx.lineTo(cx + 18, cy + 6);
            ctx.closePath();
            ctx.fill();

            // Horns (Black obsidian)
            ctx.fillStyle = '#1c1917';
            ctx.beginPath();
            ctx.moveTo(cx + 26, cy - 14);
            ctx.lineTo(cx + 20, cy - 28);
            ctx.lineTo(cx + 24, cy - 12);
            ctx.closePath();
            ctx.fill();

            // Glowing Golden Evil Eyes
            ctx.fillStyle = '#fde047';
            ctx.fillRect(cx + 32, cy - 9, 3, 2);
            ctx.fillStyle = '#000000';
            ctx.fillRect(cx + 33, cy - 9, 1, 2);

            // Snout & Teeth
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(cx + 40, cy - 2, 2, 2);
            ctx.fillRect(cx + 36, cy - 2, 2, 2);

            if (f === 2) {
                // Fire breath glow inside roaring maw
                ctx.fillStyle = '#facc15';
                ctx.fillRect(cx + 40, cy, 6, 6);
                ctx.fillStyle = '#ef4444';
                ctx.fillRect(cx + 44, cy - 2, 8, 8);
            }

            // Razor Claws
            ctx.fillStyle = '#1c1917';
            ctx.fillRect(cx + 6, cy + 12, 4, 8);
            ctx.fillRect(cx + 14, cy + 12, 4, 8);
            ctx.fillStyle = '#f8fafc';
            ctx.fillRect(cx + 8, cy + 18, 2, 3);
            ctx.fillRect(cx + 16, cy + 18, 2, 3);

            // Leathery Bat Wings (Animated: Up / Down)
            const wingColor = '#7f1d1d';
            const wingMembrane = '#dc2626';

            if (f === 0 || f === 2) {
                // Wings Up
                ctx.fillStyle = wingMembrane;
                ctx.beginPath();
                ctx.moveTo(cx - 4, cy - 6);
                ctx.lineTo(cx + 4, cy - 36);
                ctx.lineTo(cx + 26, cy - 30);
                ctx.lineTo(cx + 18, cy - 14);
                ctx.closePath();
                ctx.fill();

                ctx.strokeStyle = wingColor;
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.moveTo(cx - 4, cy - 6);
                ctx.lineTo(cx + 4, cy - 36);
                ctx.lineTo(cx + 26, cy - 30);
                ctx.stroke();
            } else if (f === 1) {
                // Wings Down
                ctx.fillStyle = wingMembrane;
                ctx.beginPath();
                ctx.moveTo(cx - 4, cy);
                ctx.lineTo(cx - 10, cy + 28);
                ctx.lineTo(cx + 18, cy + 26);
                ctx.lineTo(cx + 14, cy + 6);
                ctx.closePath();
                ctx.fill();

                ctx.strokeStyle = wingColor;
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.moveTo(cx - 4, cy);
                ctx.lineTo(cx - 10, cy + 28);
                ctx.lineTo(cx + 18, cy + 26);
                ctx.stroke();
            }
        }

        scene.textures.addSpriteSheet('dragon', canvas, { frameWidth: 96, frameHeight: 80 });
    }

    // ==========================================
    // DECORATIONS (Torches, Clouds, Mountains, Castle Tower)
    // ==========================================
    static generateDecorations(scene) {
        // Torch animated (16x24, 3 frames -> 48x24)
        const { canvas: tCanvas, ctx: tCtx } = this.createCanvas(48, 24);
        for (let f = 0; f < 3; f++) {
            const ox = f * 16;
            // Sconce
            tCtx.fillStyle = '#475569';
            tCtx.fillRect(ox + 6, 12, 4, 8);
            tCtx.fillRect(ox + 4, 10, 8, 3);
            // Flame
            tCtx.fillStyle = '#ef4444';
            tCtx.fillRect(ox + 5, 4 - (f % 2), 6, 7);
            tCtx.fillStyle = '#f59e0b';
            tCtx.fillRect(ox + 6, 5 - (f % 2), 4, 5);
            tCtx.fillStyle = '#fef08a';
            tCtx.fillRect(ox + 7, 6 - (f % 2), 2, 3);
        }
        scene.textures.addSpriteSheet('torch', tCanvas, { frameWidth: 16, frameHeight: 24 });

        // Royal Banner (16x32)
        const { canvas: banCanvas, ctx: banCtx } = this.createCanvas(16, 32);
        banCtx.fillStyle = '#78350f';
        banCtx.fillRect(1, 2, 14, 2); // hanger
        banCtx.fillStyle = '#dc2626';
        banCtx.beginPath();
        banCtx.moveTo(2, 4);
        banCtx.lineTo(14, 4);
        banCtx.lineTo(14, 26);
        banCtx.lineTo(8, 32);
        banCtx.lineTo(2, 26);
        banCtx.closePath();
        banCtx.fill();
        // Golden lion emblem
        banCtx.fillStyle = '#fde047';
        banCtx.fillRect(6, 10, 4, 8);
        banCtx.fillRect(5, 12, 6, 4);
        scene.textures.addCanvas('banner', banCanvas);

        // Fluffy Pixel Cloud (64x24)
        const { canvas: cldCanvas, ctx: cldCtx } = this.createCanvas(64, 24);
        cldCtx.fillStyle = '#ffffff';
        cldCtx.beginPath();
        cldCtx.arc(16, 16, 8, 0, Math.PI * 2);
        cldCtx.arc(28, 12, 11, 0, Math.PI * 2);
        cldCtx.arc(42, 14, 9, 0, Math.PI * 2);
        cldCtx.arc(52, 16, 6, 0, Math.PI * 2);
        cldCtx.fill();
        scene.textures.addCanvas('cloud', cldCanvas);

        // Tower Door / Entrance (32x48)
        const { canvas: doorCanvas, ctx: drCtx } = this.createCanvas(32, 48);
        drCtx.fillStyle = '#1e293b';
        drCtx.beginPath();
        drCtx.arc(16, 16, 14, Math.PI, 0);
        drCtx.lineTo(30, 48);
        drCtx.lineTo(2, 48);
        drCtx.closePath();
        drCtx.fill();
        // Wooden door planks
        drCtx.fillStyle = '#5c3312';
        drCtx.fillRect(6, 16, 20, 32);
        drCtx.fillStyle = '#854d0e';
        drCtx.fillRect(15, 16, 2, 32);
        // Iron ring
        drCtx.fillStyle = '#d4af37';
        drCtx.fillRect(20, 32, 3, 4);
        scene.textures.addCanvas('tower_door', doorCanvas);
    }
}

window.TextureGenerator = TextureGenerator;
